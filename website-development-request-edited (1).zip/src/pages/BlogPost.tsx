import { Link, useParams, Navigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, ArrowRight, Clock, Tag } from "lucide-react";
import { FadeUp } from "../components/ui";
import Portrait from "../components/Portrait";
import { POSTS, getPost, type Block } from "../data/posts";
import { useSignup } from "../components/SignupProvider";

const EASE = [0.22, 1, 0.36, 1] as const;

function BlockRenderer({ block }: { block: Block }) {
  switch (block.type) {
    case "h":
      return <h3>{block.text}</h3>;
    case "quote":
      return <blockquote>{block.text}</blockquote>;
    case "pull":
      return <p className="pull">{block.text}</p>;
    case "list":
      return (
        <ul>
          {block.items.map((it, i) => (
            <li key={i}>{it}</li>
          ))}
        </ul>
      );
    default:
      return <p>{block.text}</p>;
  }
}

export default function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  const post = slug ? getPost(slug) : undefined;
  const { openSignup } = useSignup();

  if (!post) return <Navigate to="/blog" replace />;

  const idx = POSTS.findIndex((p) => p.slug === post.slug);
  const prev = POSTS[idx - 1];
  const next = POSTS[idx + 1];

  return (
    <>
      {/* ---------- header ---------- */}
      <article>
        <header className="border-b border-line bg-surface pt-28 pb-12 sm:pt-32 lg:pt-40 lg:pb-16">
          <div className="mx-auto max-w-3xl px-5 sm:px-8">
            <FadeUp>
              <Link
                to="/blog"
                className="group inline-flex items-center gap-2 font-sans text-[11px] font-semibold uppercase tracking-[0.18em] text-muted transition-colors hover:text-crimson"
              >
                <ArrowLeft className="h-3.5 w-3.5 transition-transform duration-300 group-hover:-translate-x-1" />
                All posts
              </Link>
            </FadeUp>

            <FadeUp delay={0.08}>
              <div className="mt-8 flex flex-wrap items-center gap-x-4 gap-y-2 font-sans text-[11px] uppercase tracking-[0.16em] text-muted">
                <span className="flex items-center gap-1.5 text-crimson">
                  <Tag className="h-3 w-3" />
                  {post.category}
                </span>
                <span className="h-1 w-1 rounded-full bg-line" />
                <span className="flex items-center gap-1.5">
                  <Clock className="h-3 w-3" />
                  {post.readTime}
                </span>
              </div>
            </FadeUp>

            <FadeUp delay={0.14}>
              <h1 className="mt-6 font-display text-[2.6rem] font-light leading-[1.05] tracking-[-0.02em] text-ink sm:text-[3.4rem]">
                {post.title}
              </h1>
            </FadeUp>

            <FadeUp delay={0.2}>
              <p className="mt-6 font-serif text-[1.18rem] italic leading-relaxed text-muted">
                {post.excerpt}
              </p>
            </FadeUp>

            <FadeUp delay={0.26}>
              <div className="mt-9 flex items-center gap-3.5 border-t border-line pt-7">
                <Portrait className="h-12 w-12 rounded-full text-[0.28rem]" />
                <div>
                  <p className="font-sans text-[13px] font-semibold text-ink">Steven Calkum</p>
                  <p className="mt-0.5 font-serif text-[0.92rem] text-muted">
                    Author of <em>Freeborn</em>
                  </p>
                </div>
              </div>
            </FadeUp>
          </div>
        </header>

        {/* ---------- hero image ---------- */}
        {post.image && (
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3, ease: EASE }}
            className="mx-auto max-w-5xl px-5 py-12 sm:px-8 lg:py-16"
          >
            <div className="overflow-hidden rounded-2xl">
              <img
                src={post.image}
                alt=""
                className="aspect-[16/9] w-full object-cover"
              />
            </div>
          </motion.div>
        )}

        {/* ---------- body ---------- */}
        <div className="mx-auto max-w-3xl px-5 pb-16 sm:px-8 lg:pb-24">
          <div className="prose-post">
            {post.blocks.map((b, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.7, ease: EASE }}
              >
                <BlockRenderer block={b} />
              </motion.div>
            ))}
          </div>

          {/* tags / share */}
          <FadeUp>
            <div className="mt-14 flex flex-wrap items-center justify-between gap-5 border-t border-line pt-8">
              <span className="font-sans text-[11px] font-semibold uppercase tracking-[0.16em] text-muted">
                Filed under
              </span>
              <div className="flex flex-wrap gap-2">
                {[post.category, "Freeborn", "Shattered Empire"].map((t) => (
                  <span
                    key={t}
                    className="rounded-full border border-line px-3.5 py-1.5 font-sans text-[11px] font-semibold uppercase tracking-[0.12em] text-muted"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </FadeUp>

          {/* author card */}
          <FadeUp>
            <div className="mt-12 flex flex-col gap-6 rounded-2xl border border-line bg-surface p-8 sm:flex-row sm:items-center">
              <Portrait className="h-20 w-20 shrink-0 rounded-full text-[0.4rem]" />
              <div className="flex-1">
                <p className="label text-crimson">About the author</p>
                <p className="mt-3 font-serif text-[1.05rem] leading-relaxed text-muted">
                  Steven Calkum is a fantasy author and former Bureau of Land
                  Management range manager. He wrote <em className="text-ink">Freeborn</em>,
                  an adult coming-of-age fantasy, available in paperback and ebook.
                </p>
              </div>
              <button
                onClick={openSignup}
                className="shrink-0 self-start rounded-full bg-crimson px-6 py-3 font-sans text-[11.5px] font-semibold uppercase tracking-[0.16em] text-white transition-shadow duration-300 hover:shadow-[0_14px_30px_-12px_rgba(184,31,43,0.7)] sm:self-auto"
              >
                Join the list
              </button>
            </div>
          </FadeUp>
        </div>
      </article>

      {/* ---------- prev / next ---------- */}
      <nav className="border-t border-line bg-surface">
        <div className="mx-auto grid max-w-7xl gap-px bg-line sm:grid-cols-2">
          {prev ? (
            <Link
              to={`/blog/${prev.slug}`}
              className="group bg-surface p-8 transition-colors duration-400 hover:bg-paper sm:p-10"
            >
              <span className="flex items-center gap-2 font-sans text-[11px] font-semibold uppercase tracking-[0.16em] text-muted">
                <ArrowLeft className="h-3.5 w-3.5 transition-transform duration-300 group-hover:-translate-x-1" />
                Previous
              </span>
              <p className="mt-4 font-display text-[1.55rem] font-normal leading-tight tracking-tight text-ink transition-colors group-hover:text-crimson">
                {prev.title}
              </p>
            </Link>
          ) : (
            <div className="hidden bg-surface sm:block" />
          )}
          {next && (
            <Link
              to={`/blog/${next.slug}`}
              className="group bg-surface p-8 text-right transition-colors duration-400 hover:bg-paper sm:p-10"
            >
              <span className="flex items-center justify-end gap-2 font-sans text-[11px] font-semibold uppercase tracking-[0.16em] text-muted">
                Next
                <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
              </span>
              <p className="mt-4 font-display text-[1.55rem] font-normal leading-tight tracking-tight text-ink transition-colors group-hover:text-crimson">
                {next.title}
              </p>
            </Link>
          )}
        </div>
      </nav>
    </>
  );
}
