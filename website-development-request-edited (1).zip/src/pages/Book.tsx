import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Check,
  ArrowUpRight,
  BookMarked,
  AlertTriangle,
  TreePine,
  Pickaxe,
  Flame,
  Mountain,
  Fingerprint,
  Shield,
  Heart,
  Flag,
} from "lucide-react";
import BookCover from "../components/BookCover";
import { AmazonButton, FadeUp, SectionLabel } from "../components/ui";
import { useSignup } from "../components/SignupProvider";
import { BOOK, AMAZON_URL } from "../data/site";
import WhereToBuy from "../components/WhereToBuy";
import MapSection from "../components/MapSection";

const EASE = [0.22, 1, 0.36, 1] as const;

const THEMES = [
  { icon: Fingerprint, title: "Identity", body: "A half-elf with no people has to decide who he is when no one will decide it for him." },
  { icon: Shield, title: "Honor", body: "What you owe, what you refuse to pay, and the code you keep when it would be easier not to." },
  { icon: Heart, title: "Chosen family", body: "The people who stay are the people who count, whatever blood says." },
  { icon: Flag, title: "Prejudice", body: "Fighting back has real consequences, and the book never softens them." },
];

const WORLD = [
  { icon: TreePine, title: "Living tree cities", body: "Elven cities that grow rather than are built." },
  { icon: Pickaxe, title: "Dwarven mines", body: "Deep halls, thin air and hard people." },
  { icon: Flame, title: "Volcanic lava fields", body: "Hostile ground, written with a range manager's eye." },
  { icon: Mountain, title: "Mountain trails", body: "Long roads where tracking and weather decide everything." },
];

export default function BookPage() {
  const { openSignup } = useSignup();

  return (
    <>
      {/* header */}
      <section className="relative overflow-hidden border-b border-line bg-surface pt-28 pb-16 sm:pt-32 lg:pt-40 lg:pb-24">
        <div className="pointer-events-none absolute -right-40 -top-32 h-[30rem] w-[30rem] rounded-full bg-crimson/[0.06]" />
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 sm:px-8 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20">
          <motion.div
            initial={{ opacity: 0, y: 48 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.1, delay: 0.2, ease: EASE }}
            className="mx-auto w-56 sm:w-64 lg:mx-0 lg:w-full lg:max-w-xs"
          >
            <BookCover float className="mx-auto" />
          </motion.div>

          <div>
            <FadeUp>
              <p className="label text-crimson">{BOOK.genre} · {BOOK.subgenre}</p>
            </FadeUp>
            <FadeUp delay={0.08}>
              <h1 className="mt-6 font-display text-[3.4rem] font-light leading-[0.95] tracking-[-0.02em] text-ink sm:text-[4.5rem] lg:text-[5.6rem]">
                Freeborn
              </h1>
            </FadeUp>
            <FadeUp delay={0.14}>
              <p className="mt-4 font-serif text-[1.3rem] italic text-crimson sm:text-[1.5rem]">
                {BOOK.tagline}
              </p>
            </FadeUp>
            <FadeUp delay={0.2}>
              <p className="mt-7 max-w-2xl font-serif text-[1.12rem] leading-[1.8] text-muted">
                {BOOK.about}
              </p>
            </FadeUp>
            <FadeUp delay={0.28}>
              <div className="mt-8 flex flex-wrap items-center gap-x-7 gap-y-3">
                {["Mentor & apprentice", "Rich world-building", "Elf · dwarf · halfling"].map((g) => (
                  <span
                    key={g}
                    className="flex items-center gap-2 font-sans text-[11px] font-semibold uppercase tracking-[0.16em] text-ink/70"
                  >
                    <Check className="h-3 w-3 text-crimson" strokeWidth={3} />
                    {g}
                  </span>
                ))}
              </div>
            </FadeUp>
            <FadeUp delay={0.34} className="mt-10 flex flex-wrap items-center gap-3.5">
              <AmazonButton label="Buy Freeborn on Amazon" />
              <button
                onClick={openSignup}
                className="rounded-full border border-crimson px-7 py-3.5 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-crimson transition-colors duration-300 hover:bg-crimson hover:text-white"
              >
                Join the reader list
              </button>
            </FadeUp>
          </div>
        </div>
      </section>

      {/* synopsis + details */}
      <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:py-28">
        <div className="grid gap-14 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-7">
            <SectionLabel>The Story</SectionLabel>
            <FadeUp delay={0.08}>
              <div className="mt-7 space-y-6 font-serif text-[1.14rem] leading-[1.85] text-ink/85">
                <p className="font-display text-[1.7rem] font-light leading-[1.35] text-ink">
                  Freeborn was born in a blizzard to an escaped slave who died
                  giving him <span className="italic text-crimson">freedom.</span>
                </p>
                <p>
                  Raised on the fringe by Tishamon the Long Walker, a
                  five-hundred-year-old elf woodsman, he learns to track, fight,
                  and think his way across the Shattered Empire.
                </p>
                <p>
                  But a half-elf with no people belongs nowhere. When a powerful
                  Fire Elf family decides he must pay for fighting back, Freeborn
                  faces a deadline, a debt, and enemies on every road.
                </p>
                <p className="font-display text-[1.4rem] font-light italic leading-[1.5] text-crimson">
                  A coming-of-age fantasy about identity, honor, and the family
                  you choose.
                </p>
              </div>
            </FadeUp>
          </div>

          <div className="lg:col-span-5">
            <FadeUp delay={0.12}>
              <div className="rounded-xl border border-line bg-surface p-8">
                <div className="flex items-center gap-3">
                  <BookMarked className="h-5 w-5 text-crimson" strokeWidth={1.6} />
                  <h3 className="font-display text-xl font-semibold tracking-tight text-ink">
                    At a glance
                  </h3>
                </div>
                <dl className="mt-7 divide-y divide-line">
                  {[
                    ["Title", BOOK.title],
                    ["Author", BOOK.author],
                    ["Genre", BOOK.genre],
                    ["Style", BOOK.subgenre],
                    ["Setting", "The Shattered Empire"],
                    ["Audience", "Adult readers"],
                  ].map(([k, v]) => (
                    <div key={k} className="flex items-baseline justify-between gap-6 py-3.5">
                      <dt className="font-sans text-[11px] font-semibold uppercase tracking-[0.16em] text-muted">
                        {k}
                      </dt>
                      <dd className="text-right font-serif text-[1.02rem] text-ink">{v}</dd>
                    </div>
                  ))}
                </dl>
                <a
                  href={AMAZON_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-8 flex w-full items-center justify-center gap-2.5 rounded-full bg-crimson py-4 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-white transition-shadow duration-300 hover:shadow-[0_16px_34px_-14px_rgba(184,31,43,0.7)]"
                >
                  View on Amazon
                  <ArrowUpRight className="h-3.5 w-3.5" />
                </a>
              </div>
            </FadeUp>
          </div>
        </div>
      </section>

      <MapSection />

      <WhereToBuy />

      {/* why readers will love it */}
      <section className="border-y border-line bg-surface">
        <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:py-24">
          <SectionLabel>Why Readers Will Love It</SectionLabel>
          <FadeUp delay={0.08}>
            <h2 className="mt-6 max-w-2xl font-display text-4xl font-light leading-[1.06] tracking-tight text-ink sm:text-5xl">
              Five reasons to <span className="italic text-crimson">walk the road</span>
            </h2>
          </FadeUp>
          <ul className="mt-12 grid gap-px overflow-hidden rounded-xl bg-line sm:grid-cols-2 lg:grid-cols-5">
            {BOOK.loveIt.map((t, i) => (
              <FadeUp key={t.title} delay={0.07 * i} className="h-full">
                <li className="h-full bg-paper p-7 transition-colors duration-400 hover:bg-wash">
                  <span className="font-display text-sm italic text-crimson">0{i + 1}</span>
                  <h3 className="mt-4 font-display text-[1.35rem] font-semibold leading-tight tracking-tight text-ink">
                    {t.title}
                  </h3>
                  <p className="mt-3 font-serif text-[0.98rem] leading-relaxed text-muted">{t.body}</p>
                </li>
              </FadeUp>
            ))}
          </ul>
        </div>
      </section>

      {/* world */}
      <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:py-28">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-4">
            <SectionLabel>The World</SectionLabel>
            <FadeUp delay={0.08}>
              <h2 className="mt-6 font-display text-4xl font-light leading-[1.06] tracking-tight text-ink sm:text-[2.9rem]">
                Inside the <span className="italic text-crimson">Shattered Empire</span>
              </h2>
            </FadeUp>
            <FadeUp delay={0.16}>
              <p className="mt-6 font-serif text-[1.05rem] leading-relaxed text-muted">
                The author spent a career reading real landscapes for the Bureau
                of Land Management. That eye for terrain runs through every place
                in the book.
              </p>
            </FadeUp>
          </div>
          <div className="lg:col-span-8">
            <div className="grid gap-4 sm:grid-cols-2">
              {WORLD.map((w, i) => (
                <FadeUp key={w.title} delay={0.07 * i}>
                  <div className="group h-full rounded-xl border border-line bg-surface p-7 transition-all duration-400 hover:-translate-y-1 hover:border-crimson/40 hover:shadow-[0_20px_44px_-26px_rgba(184,31,43,0.35)]">
                    <span className="flex h-11 w-11 items-center justify-center rounded-full bg-crimson-soft text-crimson">
                      <w.icon className="h-5 w-5" strokeWidth={1.6} />
                    </span>
                    <h3 className="mt-5 font-display text-xl font-semibold tracking-tight text-ink">
                      {w.title}
                    </h3>
                    <p className="mt-2 font-serif text-[1rem] leading-relaxed text-muted">{w.body}</p>
                  </div>
                </FadeUp>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* themes */}
      <section className="border-t border-line bg-surface">
        <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:py-24">
          <SectionLabel>Themes</SectionLabel>
          <FadeUp delay={0.08}>
            <h2 className="mt-6 max-w-2xl font-display text-4xl font-light leading-[1.06] tracking-tight text-ink sm:text-5xl">
              What the story is <span className="italic text-crimson">really about</span>
            </h2>
          </FadeUp>
          <div className="mt-12 grid gap-px overflow-hidden rounded-xl bg-line sm:grid-cols-2 lg:grid-cols-4">
            {THEMES.map((t, i) => (
              <FadeUp key={t.title} delay={0.07 * i} className="h-full">
                <div className="h-full bg-paper p-8 transition-colors duration-400 hover:bg-wash">
                  <t.icon className="h-6 w-6 text-crimson" strokeWidth={1.5} />
                  <h3 className="mt-5 font-display text-[1.5rem] font-semibold tracking-tight text-ink">
                    {t.title}
                  </h3>
                  <p className="mt-3 font-serif text-[1rem] leading-relaxed text-muted">{t.body}</p>
                </div>
              </FadeUp>
            ))}
          </div>
        </div>
      </section>

      {/* content note */}
      <section className="mx-auto max-w-4xl px-5 py-20 sm:px-8 lg:py-24">
        <FadeUp>
          <div className="rounded-2xl border border-crimson/30 bg-crimson-soft p-8 sm:p-11">
            <div className="flex items-center gap-3.5">
              <AlertTriangle className="h-7 w-7 text-crimson" strokeWidth={1.6} />
              <p className="label text-crimson">Content note · adult readers</p>
            </div>
            <p className="mt-6 font-serif text-[1.15rem] leading-[1.8] text-ink/90">
              {BOOK.contentNote}
            </p>
            <ul className="mt-6 flex flex-wrap gap-2.5">
              {["Slavery", "Sexual violence", "Captivity", "Graphic battle violence"].map((t) => (
                <li
                  key={t}
                  className="rounded-full border border-crimson/40 bg-paper px-4 py-2 font-sans text-[11.5px] font-semibold uppercase tracking-[0.14em] text-crimson"
                >
                  {t}
                </li>
              ))}
            </ul>
            <Link
              to="/blog/who-freeborn-is-for"
              className="mt-8 inline-flex items-center gap-2 font-sans text-[11.5px] font-semibold uppercase tracking-[0.16em] text-crimson hover:underline"
            >
              Read the author's note
              <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        </FadeUp>
      </section>
    </>
  );
}
