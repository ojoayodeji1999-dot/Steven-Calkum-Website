import { useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, Clock } from "lucide-react";
import { FadeUp } from "../components/ui";
import { POSTS, CATEGORIES } from "../data/posts";
import { useSignup } from "../components/SignupProvider";

const EASE = [0.22, 1, 0.36, 1] as const;

export default function Blog() {
  const [filter, setFilter] = useState<string>("All");
  const featured = POSTS.find((p) => p.featured) ?? POSTS[0];
  const rest = POSTS.filter(
    (p) => p.slug !== featured.slug && (filter === "All" || p.category === filter)
  );
  const { openSignup } = useSignup();

  return (
    <>
      {/* header */}
      <section className="border-b border-line bg-surface pt-28 pb-14 sm:pt-32 lg:pt-40 lg:pb-20">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <FadeUp>
            <p className="label text-crimson">The Journal</p>
          </FadeUp>
          <FadeUp delay={0.08}>
            <h1 className="mt-6 max-w-3xl font-display text-[3rem] font-light leading-[1.02] tracking-[-0.02em] text-ink sm:text-[4rem] lg:text-[4.6rem]">
              Notes from the <span className="italic text-crimson">Shattered Empire</span>
            </h1>
          </FadeUp>
          <FadeUp delay={0.16}>
            <p className="mt-7 max-w-xl font-serif text-[1.12rem] leading-relaxed text-muted">
              The long draft, the world, the characters, and the story behind
              Freeborn, in the author's own words.
            </p>
          </FadeUp>
        </div>
      </section>

      {/* featured */}
      <section className="mx-auto max-w-7xl px-5 py-16 sm:px-8 lg:py-20">
        <FadeUp>
          <Link
            to={`/blog/${featured.slug}`}
            className="group grid gap-8 overflow-hidden rounded-2xl border border-line bg-surface transition-all duration-500 hover:border-crimson/40 hover:shadow-[0_30px_70px_-40px_rgba(184,31,43,0.4)] lg:grid-cols-2"
          >
            <div className="relative aspect-[16/11] overflow-hidden lg:aspect-auto lg:min-h-[22rem]">
              {featured.image ? (
                <img
                  src={featured.image}
                  alt=""
                  className="h-full w-full object-cover transition-transform duration-[1400ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.05]"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-crimson to-crimson-dark">
                  <span className="font-display text-7xl font-light italic text-white/90">F</span>
                </div>
              )}
              <span className="absolute left-5 top-5 rounded-full bg-crimson px-3.5 py-1.5 font-sans text-[10px] font-semibold uppercase tracking-[0.16em] text-white">
                Featured
              </span>
            </div>
            <div className="flex flex-col justify-center p-8 sm:p-11">
              <div className="flex flex-wrap items-center gap-x-4 gap-y-2 font-sans text-[11px] uppercase tracking-[0.16em] text-muted">
                <span className="text-crimson">{featured.category}</span>
                <span className="h-1 w-1 rounded-full bg-line" />
                <span className="flex items-center gap-1.5">
                  <Clock className="h-3 w-3" />
                  {featured.readTime}
                </span>
              </div>
              <h2 className="mt-5 font-display text-[2.1rem] font-light leading-[1.1] tracking-tight text-ink transition-colors duration-300 group-hover:text-crimson sm:text-[2.6rem]">
                {featured.title}
              </h2>
              <p className="mt-5 font-serif text-[1.08rem] leading-relaxed text-muted">
                {featured.excerpt}
              </p>
              <span className="mt-8 inline-flex items-center gap-2.5 font-sans text-[11.5px] font-semibold uppercase tracking-[0.16em] text-crimson">
                Read the post
                <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1.5" />
              </span>
            </div>
          </Link>
        </FadeUp>
      </section>

      {/* filters */}
      <section className="mx-auto max-w-7xl px-5 sm:px-8">
        <FadeUp>
          <div className="flex flex-wrap items-center gap-2.5 border-t border-line pt-8">
            <span className="mr-2 font-sans text-[11px] font-semibold uppercase tracking-[0.16em] text-muted">
              Filter
            </span>
            {["All", ...CATEGORIES].map((c) => (
              <button
                key={c}
                onClick={() => setFilter(c)}
                className={`rounded-full border px-4 py-2 font-sans text-[11.5px] font-semibold uppercase tracking-[0.14em] transition-all duration-300 ${
                  filter === c
                    ? "border-crimson bg-crimson text-white"
                    : "border-line text-muted hover:border-crimson hover:text-crimson"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </FadeUp>
      </section>

      {/* grid */}
      <section className="mx-auto max-w-7xl px-5 py-14 sm:px-8 lg:py-20">
        <AnimatePresence mode="popLayout">
          <motion.div
            key={filter}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.45, ease: EASE }}
            className="grid gap-x-8 gap-y-14 md:grid-cols-2 lg:grid-cols-3"
          >
            {rest.map((p) => (
              <Link key={p.slug} to={`/blog/${p.slug}`} className="group flex flex-col">
                <div className="relative aspect-[16/10] overflow-hidden rounded-lg bg-surface-2">
                  {p.image ? (
                    <img
                      src={p.image}
                      alt=""
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.06]"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-crimson to-crimson-dark">
                      <span className="font-display text-5xl font-light italic text-white/90">
                        {p.category[0]}
                      </span>
                    </div>
                  )}
                  <span className="absolute left-4 top-4 rounded-full bg-paper/95 px-3 py-1.5 font-sans text-[10px] font-semibold uppercase tracking-[0.16em] text-crimson">
                    {p.category}
                  </span>
                </div>
                <div className="flex flex-1 flex-col pt-6">
                  <p className="font-sans text-[11px] uppercase tracking-[0.16em] text-muted">
                    {p.readTime}
                  </p>
                  <h3 className="mt-3 font-display text-[1.65rem] font-normal leading-[1.18] tracking-tight text-ink transition-colors duration-300 group-hover:text-crimson">
                    {p.title}
                  </h3>
                  <p className="mt-3 flex-1 font-serif text-[1.02rem] leading-relaxed text-muted">
                    {p.excerpt}
                  </p>
                  <span className="mt-5 inline-flex items-center gap-2 font-sans text-[11.5px] font-semibold uppercase tracking-[0.16em] text-crimson">
                    Read post
                    <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
                  </span>
                </div>
              </Link>
            ))}
          </motion.div>
        </AnimatePresence>

        {rest.length === 0 && (
          <p className="py-16 text-center font-serif text-[1.05rem] text-muted">
            No posts in this category yet — check back soon.
          </p>
        )}
      </section>

      {/* newsletter */}
      <section className="border-t border-line bg-crimson">
        <div className="mx-auto grid max-w-7xl items-center gap-8 px-5 py-16 sm:px-8 lg:grid-cols-[1.2fr_1fr] lg:py-20">
          <div>
            <p className="label text-white/70">Never Miss a Note</p>
            <h2 className="mt-5 max-w-xl font-display text-3xl font-light leading-[1.1] tracking-tight text-white sm:text-4xl">
              Join the reader list for <span className="italic">updates.</span>
            </h2>
          </div>
          <div className="flex flex-col items-start gap-3 lg:items-end">
            <p className="max-w-sm font-serif text-[1.02rem] leading-relaxed text-white/80 lg:text-right">
              Plus poetry, short fiction and updates from the wider universe.
            </p>
            <button
              onClick={openSignup}
              className="rounded-full bg-white px-7 py-3.5 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-crimson transition-transform duration-300 hover:-translate-y-0.5"
            >
              Join the reader list
            </button>
          </div>
        </div>
      </section>
    </>
  );
}
