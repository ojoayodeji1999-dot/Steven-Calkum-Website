import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { PenLine, MapPin, BookOpen, Check, ChevronDown, MessageSquare, Send } from "lucide-react";
import { FadeUp, SectionLabel } from "../components/ui";
import { CONTACT_REASONS, AMAZON_URL, PEN_NAME } from "../data/site";
import { useSignup } from "../components/SignupProvider";

const EASE = [0.22, 1, 0.36, 1] as const;

const DETAILS = [
  {
    icon: PenLine,
    label: "Online as",
    value: PEN_NAME,
    note: "Poetry, short fiction, and updates on the wider universe of the Shattered Empire.",
  },
  {
    icon: MapPin,
    label: "Based in",
    value: "Wyoming, USA",
    note: "Raised in East Central Colorado, now writing from Wyoming.",
  },
  {
    icon: BookOpen,
    label: "Read the book",
    value: "Freeborn: Genesis (paperback and ebook)",
    note: "Adult fantasy. Please see the content note on the book page first.",
  },
];

const FAQ = [
  {
    q: "Where can I buy Freeborn?",
    a: "Freeborn is available in paperback and ebook from Amazon, Barnes & Noble, Walmart, and several international stores. The Where to Buy section on the Book page lists every link, and Hoopla and OverDrive let you borrow the ebook from a library.",
  },
  {
    q: "Is Freeborn suitable for younger readers?",
    a: "No. Freeborn is an adult fantasy. It deals with slavery, sexual violence, captivity, and graphic battle violence, so it is written for adult readers only.",
  },
  {
    q: "What kind of story is it?",
    a: "A coming-of-age fantasy about identity, honor, and the family you choose, with a mentor and apprentice at its core, set across a richly built world of tree cities, dwarven mines and volcanic lava fields.",
  },
  {
    q: "How long did it take to write?",
    a: "Between 1998 and 2006, Steven spent eight years drafting, editing and transcribing the novel by hand and on office computers during his professional downtime.",
  },
  {
    q: "Where can I find more of his writing?",
    a: "Writing as Shattered Empire Scribe, Steven shares poetry, short fiction, and updates on his wider universe. Join the reader list to hear when there is something new.",
  },
];

export default function Contact() {
  const { openSignup } = useSignup();
  const [form, setForm] = useState({
    name: "",
    email: "",
    reason: CONTACT_REASONS[0],
    subject: "",
    message: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sent, setSent] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm((f) => ({ ...f, [k]: e.target.value }));
    setErrors((x) => ({ ...x, [k]: "" }));
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (!form.name.trim()) next.name = "Please tell me your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim()))
      next.email = "Please enter a valid email address.";
    if (form.message.trim().length < 12)
      next.message = "A sentence or two would be lovely.";
    setErrors(next);
    if (Object.keys(next).length === 0) setSent(true);
  };

  const field =
    "mt-2 w-full border-b border-line bg-transparent pb-2.5 font-serif text-[1.05rem] text-ink transition-colors placeholder:text-muted/45 focus:border-crimson";

  return (
    <>
      {/* ---------- header ---------- */}
      <section className="border-b border-line bg-surface pt-28 pb-14 sm:pt-32 lg:pt-40 lg:pb-20">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <FadeUp>
            <p className="label text-crimson">Get in Touch</p>
          </FadeUp>
          <FadeUp delay={0.08}>
            <h1 className="mt-6 max-w-3xl font-display text-[3rem] font-light leading-[1.02] tracking-[-0.02em] text-ink sm:text-[4rem] lg:text-[4.6rem]">
              Say hello to <span className="italic text-crimson">Steven.</span>
            </h1>
          </FadeUp>
          <FadeUp delay={0.16}>
            <p className="mt-7 max-w-xl font-serif text-[1.12rem] leading-relaxed text-muted">
              A question about Freeborn, feedback on the story, or a note about
              the wider Shattered Empire. Send it through the form below.
            </p>
          </FadeUp>
        </div>
      </section>

      {/* ---------- form + details ---------- */}
      <section className="mx-auto max-w-7xl px-5 py-16 sm:px-8 lg:py-24">
        <div className="grid gap-14 lg:grid-cols-12 lg:gap-16">
          {/* form */}
          <div className="lg:col-span-7">
            <SectionLabel>Send a Message</SectionLabel>

            <AnimatePresence mode="wait">
              {sent ? (
                <motion.div
                  key="done"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.55, ease: EASE }}
                  className="mt-8 rounded-2xl border border-line bg-surface p-9 sm:p-11"
                >
                  <span className="flex h-14 w-14 items-center justify-center rounded-full bg-crimson text-white">
                    <Check className="h-6 w-6" strokeWidth={2.5} />
                  </span>
                  <h2 className="mt-7 font-display text-3xl font-light tracking-tight text-ink">
                    Thank you, {form.name.split(" ")[0] || "friend"}.
                  </h2>
                  <p className="mt-4 max-w-md font-serif text-[1.08rem] leading-relaxed text-muted">
                    Your message ({" "}
                    <em className="text-ink">{form.reason.toLowerCase()}</em>)
                    has been received.
                  </p>
                  <div className="mt-8 flex flex-wrap gap-3">
                    <button
                      onClick={() => {
                        setSent(false);
                        setForm({ name: "", email: "", reason: CONTACT_REASONS[0], subject: "", message: "" });
                      }}
                      className="rounded-full border border-line px-6 py-3 font-sans text-[11.5px] font-semibold uppercase tracking-[0.16em] text-ink transition-colors hover:border-crimson hover:text-crimson"
                    >
                      Send another
                    </button>
                    <a
                      href={AMAZON_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="rounded-full bg-crimson px-6 py-3 font-sans text-[11.5px] font-semibold uppercase tracking-[0.16em] text-white"
                    >
                      Buy Freeborn
                    </a>
                  </div>
                </motion.div>
              ) : (
                <motion.form
                  key="form"
                  onSubmit={submit}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="mt-8 space-y-8"
                >
                  <div className="grid gap-8 sm:grid-cols-2">
                    <div>
                      <label htmlFor="c-name" className="label block text-muted">
                        Your name <span className="text-crimson">*</span>
                      </label>
                      <input
                        id="c-name"
                        type="text"
                        value={form.name}
                        onChange={set("name")}
                        placeholder="Your name"
                        autoComplete="name"
                        className={field}
                      />
                      {errors.name && (
                        <p className="mt-2 font-sans text-[11.5px] font-medium text-crimson">
                          {errors.name}
                        </p>
                      )}
                    </div>
                    <div>
                      <label htmlFor="c-email" className="label block text-muted">
                        Email <span className="text-crimson">*</span>
                      </label>
                      <input
                        id="c-email"
                        type="email"
                        value={form.email}
                        onChange={set("email")}
                        placeholder="you@example.com"
                        autoComplete="email"
                        className={field}
                      />
                      {errors.email && (
                        <p className="mt-2 font-sans text-[11.5px] font-medium text-crimson">
                          {errors.email}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* reason — the option list */}
                  <div>
                    <label htmlFor="c-reason" className="label block text-muted">
                      What is this about?
                    </label>
                    <div className="relative mt-2">
                      <select
                        id="c-reason"
                        value={form.reason}
                        onChange={set("reason")}
                        className="w-full appearance-none border-b border-line bg-transparent pb-2.5 pr-8 font-serif text-[1.05rem] text-ink transition-colors focus:border-crimson"
                      >
                        {CONTACT_REASONS.map((r) => (
                          <option key={r} value={r} className="bg-paper text-ink">
                            {r}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="pointer-events-none absolute right-1 top-1.5 h-4 w-4 text-crimson" />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="c-subject" className="label block text-muted">
                      Subject
                    </label>
                    <input
                      id="c-subject"
                      type="text"
                      value={form.subject}
                      onChange={set("subject")}
                      placeholder="What is this about?"
                      className={field}
                    />
                  </div>

                  <div>
                    <label htmlFor="c-msg" className="label block text-muted">
                      Your message <span className="text-crimson">*</span>
                    </label>
                    <textarea
                      id="c-msg"
                      rows={5}
                      value={form.message}
                      onChange={set("message")}
                      placeholder="Write your message here…"
                      className={`${field} resize-none`}
                    />
                    {errors.message && (
                      <p className="mt-2 font-sans text-[11.5px] font-medium text-crimson">
                        {errors.message}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-4">
                    <button
                      type="submit"
                      className="group relative overflow-hidden rounded-full bg-crimson px-8 py-4 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-white transition-shadow duration-300 hover:shadow-[0_16px_36px_-14px_rgba(184,31,43,0.7)]"
                    >
                      <span className="absolute inset-0 -translate-x-full bg-crimson-dark transition-transform duration-400 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:translate-x-0" />
                      <span className="relative flex items-center gap-2.5">
                        <Send className="h-3.5 w-3.5" />
                        Send message
                      </span>
                    </button>
                  </div>
                </motion.form>
              )}
            </AnimatePresence>
          </div>

          {/* details */}
          <aside className="lg:col-span-5">
            <SectionLabel>Direct Lines</SectionLabel>
            <div className="mt-8 space-y-4">
              {DETAILS.map((d, i) => (
                <FadeUp key={d.label} delay={0.08 * i}>
                  <div className="rounded-xl border border-line bg-surface p-7 transition-colors duration-400 hover:border-crimson/40">
                    <div className="flex items-start gap-4">
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-crimson-soft text-crimson">
                        <d.icon className="h-4 w-4" />
                      </span>
                      <div>
                        <p className="label text-muted">{d.label}</p>
                        <p className="mt-2 font-display text-[1.2rem] font-normal leading-snug text-ink">
                            {d.value}
                          </p>
                        <p className="mt-2 font-serif text-[0.95rem] leading-relaxed text-muted">
                          {d.note}
                        </p>
                      </div>
                    </div>
                  </div>
                </FadeUp>
              ))}
            </div>

            <FadeUp delay={0.3}>
              <div className="mt-4 overflow-hidden rounded-xl bg-crimson p-8 text-white">
                <MessageSquare className="h-7 w-7" strokeWidth={1.5} />
                <h3 className="mt-5 font-display text-2xl font-light leading-snug">
                  Want updates instead?
                </h3>
                <p className="mt-3 font-serif text-[1rem] leading-relaxed text-white/80">
                  Join the reader list for news about <em>Freeborn</em>, plus
                  poetry, short fiction, and updates from the wider universe.
                </p>
                <button
                  onClick={openSignup}
                  className="mt-6 w-full rounded-full bg-white py-3.5 font-sans text-[11.5px] font-semibold uppercase tracking-[0.16em] text-crimson transition-transform duration-300 hover:-translate-y-0.5"
                >
                  Join the reader list
                </button>
              </div>
            </FadeUp>
          </aside>
        </div>
      </section>

      {/* ---------- faq ---------- */}
      <section className="border-t border-line bg-surface">
        <div className="mx-auto max-w-3xl px-5 py-16 sm:px-8 lg:py-24">
          <SectionLabel>Quick Answers</SectionLabel>
          <FadeUp delay={0.08}>
            <h2 className="mt-6 font-display text-4xl font-light leading-[1.06] tracking-tight text-ink sm:text-[2.9rem]">
              A few <span className="italic text-crimson">answers</span>
            </h2>
          </FadeUp>

          <div className="mt-10 divide-y divide-line border-y border-line">
            {FAQ.map((f, i) => (
              <div key={f.q}>
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  aria-expanded={openFaq === i}
                  className="group flex w-full items-center justify-between gap-6 py-6 text-left"
                >
                  <span
                    className={`font-display text-[1.28rem] font-normal leading-snug tracking-tight transition-colors duration-300 ${
                      openFaq === i ? "text-crimson" : "text-ink group-hover:text-crimson"
                    }`}
                  >
                    {f.q}
                  </span>
                  <motion.span
                    animate={{ rotate: openFaq === i ? 45 : 0 }}
                    transition={{ duration: 0.35, ease: EASE }}
                    className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full border transition-colors duration-300 ${
                      openFaq === i
                        ? "border-crimson bg-crimson text-white"
                        : "border-line text-muted group-hover:border-crimson group-hover:text-crimson"
                    }`}
                  >
                    +
                  </motion.span>
                </button>
                <AnimatePresence initial={false}>
                  {openFaq === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.45, ease: EASE }}
                      className="overflow-hidden"
                    >
                      <p className="max-w-xl pb-7 font-serif text-[1.06rem] leading-relaxed text-muted">
                        {f.a}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
