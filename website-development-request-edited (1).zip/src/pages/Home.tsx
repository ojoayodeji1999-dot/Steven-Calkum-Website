import { Link } from "react-router-dom";
import { motion, useReducedMotion } from "framer-motion";
import {
  ArrowRight,
  ArrowUpRight,
  AlertTriangle,
  Swords,
  Trees,
  Users,
  Scale,
  Compass,
  Sparkle,
} from "lucide-react";
import BookCover from "../components/BookCover";
import Portrait from "../components/Portrait";
import { AmazonButton, FadeUp, SectionLabel, SignupTrigger, WordReveal } from "../components/ui";
import { useSignup } from "../components/SignupProvider";
import Reviews from "../components/Reviews";
import Embers from "../components/Embers";
import HeroBackdrop from "../components/HeroBackdrop";
import CompassDial from "../components/Compass";
import QuoteBand from "../components/QuoteBand";
import MapSection from "../components/MapSection";
import WatchSection from "../components/WatchSection";
import { BOOK, AUTHOR, PEN_NAME, AMAZON_URL } from "../data/site";
import { POSTS } from "../data/posts";

const EASE = [0.22, 1, 0.36, 1] as const;

const LOVE_ICONS = [Compass, Trees, Scale, Swords, Users];

function Hero() {
  const reduce = useReducedMotion();
  const { openSignup } = useSignup();

  const lines = [
    { t: "A half-elf with", cls: "", d: 0.15 },
    { t: "no people,", cls: "italic text-crimson", d: 0.3 },
    { t: "and enemies on every road.", cls: "", d: 0.45 },
  ];

  return (
    <section className="relative overflow-hidden bg-paper pt-28 pb-16 sm:pt-32 lg:pt-40 lg:pb-24">
      <HeroBackdrop />
      <Embers className="hidden dark:block" />

      <div className="relative z-10 mx-auto grid max-w-7xl items-center gap-14 px-5 sm:px-8 lg:grid-cols-[1.1fr_0.9fr] lg:gap-20">
        <div>
          <FadeUp>
            <div className="inline-flex items-center gap-2.5 rounded-full border border-crimson/25 bg-wash px-4 py-2">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-crimson" />
              <span className="font-sans text-[11px] font-semibold uppercase tracking-[0.18em] text-crimson">
                Adult fantasy · Paperback and ebook
              </span>
            </div>
          </FadeUp>

          <h1 className="mt-7 font-display text-[2.8rem] font-light leading-[1] tracking-[-0.02em] text-ink sm:text-[3.8rem] lg:text-[4.5rem]">
            {lines.map((l) => (
              <span key={l.t} className="block overflow-hidden pb-[0.08em]">
                <motion.span
                  initial={{ y: reduce ? 0 : "110%" }}
                  animate={{ y: 0 }}
                  transition={{ duration: 1, delay: l.d, ease: EASE }}
                  className={`block ${l.cls}`}
                >
                  {l.t}
                </motion.span>
              </span>
            ))}
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.7, ease: EASE }}
            className="mt-8 max-w-xl font-serif text-[1.15rem] leading-[1.75] text-muted"
          >
            <strong className="font-normal text-ink">Freeborn</strong> is a
            coming-of-age fantasy about identity, honor, and the family you
            choose, by <span className="text-ink">{BOOK.author}</span>.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.85, ease: EASE }}
            className="mt-10 flex flex-wrap items-center gap-3.5"
          >
            <AmazonButton label="Buy Freeborn on Amazon" />
            <SignupTrigger onClick={openSignup} variant="outline" label="Join the reader list" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.05 }}
            className="mt-12 grid grid-cols-3 gap-x-4 border-t border-line pt-7 sm:flex sm:flex-wrap sm:items-center sm:gap-x-9 sm:gap-y-5"
          >
            {[
              ["8 years", "Drafted 1998 – 2006"],
              ["58 chapters", "Plus a prologue"],
              ["18+", "Adult readers"],
            ].map(([n, l], i) => (
              <div key={l} className="flex items-center gap-4 sm:gap-9">
                {i > 0 && <div className="hidden h-10 w-px bg-line sm:block" />}
                <div>
                  <p className="font-display text-xl font-light text-ink sm:text-2xl">{n}</p>
                  <p className="mt-1 font-sans text-[10px] uppercase tracking-[0.12em] text-muted sm:text-[11px] sm:tracking-[0.15em]">
                    {l}
                  </p>
                </div>
              </div>
            ))}
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 0.4, ease: EASE }}
          className="relative mx-auto w-full max-w-sm lg:max-w-none"
        >
          <div className="relative px-6 py-10 sm:px-12 sm:py-14">
            <CompassDial className="pointer-events-none absolute left-1/2 top-[44%] aspect-square w-[112%] max-w-none -translate-x-1/2 -translate-y-1/2 text-gold opacity-80" />
            <BookCover float className="relative mx-auto w-[70%] sm:w-[64%]" />
            <p className="relative mt-20 text-center font-sans text-[10.5px] font-semibold uppercase tracking-[0.24em] text-muted">
              A novel of the Shattered Empire
            </p>
          </div>
          <div className="absolute -bottom-5 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-paper px-5 py-2.5 font-sans text-[11px] font-semibold uppercase tracking-[0.16em] text-crimson shadow-[0_10px_30px_-14px_rgba(23,20,15,0.4)] ring-1 ring-line">
            Paperback and ebook
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function WorldStrip() {
  const items = [...BOOK.worldFeatures, ...BOOK.worldFeatures];
  return (
    <section className="border-y border-line bg-crimson py-5 text-white">
      <div className="relative overflow-hidden">
        <div className="animate-marquee-x flex w-max items-center">
          {items.map((t, i) => (
            <div key={i} className="flex shrink-0 items-center gap-6 px-6">
              <span className="font-display text-xl font-light italic sm:text-2xl">{t}</span>
              <Sparkle className="h-4 w-4 shrink-0 fill-white/70 text-white/70" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Synopsis() {
  return (
    <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:py-28">
      <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
        <div className="lg:col-span-5">
          <SectionLabel>The Book</SectionLabel>
          <FadeUp delay={0.08}>
            <h2 className="mt-6 font-display text-4xl font-light leading-[1.05] tracking-tight text-ink sm:text-5xl">
              <WordReveal text="Freeborn" className="italic text-crimson" />
            </h2>
          </FadeUp>
          <FadeUp delay={0.16}>
            <p className="mt-7 font-serif text-[1.12rem] leading-[1.8] text-muted">
              {BOOK.logline}
            </p>
          </FadeUp>
          <FadeUp delay={0.22}>
            <p className="mt-5 font-serif text-[1.12rem] leading-[1.8] text-muted">
              {BOOK.conflict}
            </p>
          </FadeUp>
          <FadeUp delay={0.3} className="mt-9">
            <Link
              to="/book"
              className="group inline-flex items-center gap-2.5 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-crimson"
            >
              More about the book
              <span className="h-px w-8 bg-crimson transition-all duration-300 group-hover:w-12" />
              <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
            </Link>
          </FadeUp>
        </div>

        <div className="lg:col-span-7">
          <FadeUp>
            <p className="label text-muted">Why readers will love it</p>
          </FadeUp>
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            {BOOK.loveIt.map((c, i) => {
              const Icon = LOVE_ICONS[i];
              return (
                <FadeUp key={c.title} delay={0.07 * i} className={i === 4 ? "sm:col-span-2" : ""}>
                  <div className="group h-full rounded-xl border border-line bg-surface p-7 transition-all duration-400 hover:-translate-y-1 hover:border-crimson/40 hover:shadow-[0_20px_44px_-26px_rgba(184,31,43,0.35)]">
                    <Icon className="h-6 w-6 text-crimson" strokeWidth={1.5} />
                    <h3 className="mt-5 font-display text-xl font-semibold tracking-tight text-ink">
                      {c.title}
                    </h3>
                    <p className="mt-2.5 font-serif text-[1rem] leading-relaxed text-muted">
                      {c.body}
                    </p>
                  </div>
                </FadeUp>
              );
            })}
          </div>
        </div>
      </div>

      {/* content note */}
      <FadeUp className="mt-14">
        <div className="flex items-start gap-5 rounded-xl border border-crimson/30 bg-crimson-soft p-6 sm:p-8">
          <AlertTriangle className="mt-0.5 h-6 w-6 shrink-0 text-crimson" strokeWidth={1.6} />
          <div>
            <p className="label text-crimson">Content note · adult readers</p>
            <p className="mt-3 max-w-3xl font-serif text-[1.05rem] leading-relaxed text-ink/85">
              {BOOK.contentNote}
            </p>
          </div>
        </div>
      </FadeUp>
    </section>
  );
}

function AuthorBlock() {
  return (
    <section className="border-t border-line bg-surface">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 py-20 sm:px-8 lg:grid-cols-[0.85fr_1.15fr] lg:gap-20 lg:py-28">
        <FadeUp>
          <div className="relative mx-auto max-w-sm lg:max-w-none">
            <div className="overflow-hidden rounded-xl">
              <Portrait className="aspect-[4/5] w-full transition-transform duration-[1400ms] hover:scale-[1.04]" />
            </div>
            <div className="absolute -bottom-6 -right-4 w-40 rounded-lg bg-crimson p-5 text-white shadow-[0_24px_48px_-20px_rgba(184,31,43,0.6)] sm:-right-6 sm:w-44">
              <p className="font-display text-3xl font-light leading-none">8 yrs</p>
              <p className="mt-2 font-sans text-[10px] font-semibold uppercase leading-relaxed tracking-[0.16em] text-white/80">
                Drafting Freeborn, 1998 – 2006
              </p>
            </div>
          </div>
        </FadeUp>

        <div>
          <SectionLabel>About the Author</SectionLabel>
          <FadeUp delay={0.08}>
            <h2 className="mt-6 font-display text-4xl font-light leading-[1.06] tracking-tight text-ink sm:text-5xl">
              A rancher's son who learned to
              <span className="italic text-crimson"> read the land.</span>
            </h2>
          </FadeUp>
          <FadeUp delay={0.16}>
            <div className="mt-7 space-y-5 font-serif text-[1.12rem] leading-[1.8] text-muted">
              <p>
                Steven Calkum was raised on a small ranch in East Central
                Colorado. He studied Range Management and Agriculture at
                Colorado State University, then spent his career as a range
                manager for the Bureau of Land Management, monitoring public
                grazing lands and working with local ranchers.
              </p>
              <p>
                Years of writing technical reports and environmental impact
                statements gave him a strong foundation in structured, precise
                writing. It shows on every page of{" "}
                <em className="text-ink">Freeborn</em>, from the lava fields and
                mountain trails to the way his characters read the land.
              </p>
              <p>
                He retired early in 2014 to focus on fiction, and lives in {AUTHOR.location}.
              </p>
            </div>
          </FadeUp>
          <FadeUp delay={0.24} className="mt-9 flex flex-wrap items-center gap-x-8 gap-y-4">
            <Link
              to="/contact"
              className="group inline-flex items-center gap-2.5 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-crimson"
            >
              Get in touch
              <span className="h-px w-8 bg-crimson transition-all duration-300 group-hover:w-12" />
              <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
            </Link>
            <span className="font-sans text-[11.5px] uppercase tracking-[0.14em] text-muted">
              Online as <span className="text-ink">{PEN_NAME}</span>
            </span>
          </FadeUp>
        </div>
      </div>
    </section>
  );
}

function LatestPosts() {
  const posts = POSTS.slice(0, 3);
  return (
    <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:py-28">
      <div className="mb-12 flex flex-wrap items-end justify-between gap-6">
        <div>
          <SectionLabel>The Journal</SectionLabel>
          <FadeUp delay={0.08}>
            <h2 className="mt-6 font-display text-4xl font-light leading-[1.05] tracking-tight text-ink sm:text-5xl">
              From the <span className="italic text-crimson">Shattered Empire</span>
            </h2>
          </FadeUp>
        </div>
        <FadeUp delay={0.14}>
          <Link
            to="/blog"
            className="group inline-flex items-center gap-2.5 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-crimson"
          >
            All posts
            <span className="h-px w-8 bg-crimson transition-all duration-300 group-hover:w-12" />
            <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
          </Link>
        </FadeUp>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        {posts.map((p, i) => (
          <FadeUp key={p.slug} delay={0.08 * i}>
            <Link to={`/blog/${p.slug}`} className="group flex h-full flex-col">
              <div className="relative aspect-[16/10] overflow-hidden rounded-lg bg-surface-2">
                {p.image ? (
                  <img
                    src={p.image}
                    alt=""
                    className="h-full w-full object-cover transition-transform duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.06]"
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-crimson to-crimson-dark">
                    <span className="font-display text-5xl font-light italic text-white/90">F</span>
                  </div>
                )}
                <span className="absolute left-4 top-4 rounded-full bg-paper/95 px-3 py-1.5 font-sans text-[10px] font-semibold uppercase tracking-[0.16em] text-crimson">
                  {p.category}
                </span>
              </div>
              <div className="flex flex-1 flex-col pt-6">
                <p className="font-sans text-[11px] uppercase tracking-[0.16em] text-muted">
                  {p.readTime}
                </p>
                <h3 className="mt-3 font-display text-[1.6rem] font-normal leading-[1.2] tracking-tight text-ink transition-colors duration-300 group-hover:text-crimson">
                  {p.title}
                </h3>
                <p className="mt-3 flex-1 font-serif text-[1.02rem] leading-relaxed text-muted">
                  {p.excerpt}
                </p>
                <span className="mt-5 inline-flex items-center gap-2 font-sans text-[11.5px] font-semibold uppercase tracking-[0.16em] text-crimson">
                  Read post
                  <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
                </span>
              </div>
            </Link>
          </FadeUp>
        ))}
      </div>
    </section>
  );
}

function CtaBand() {
  const { openSignup } = useSignup();
  return (
    <section className="relative overflow-hidden bg-crimson text-white">
      <div className="pointer-events-none absolute -left-20 -top-24 h-80 w-80 rounded-full bg-white/[0.06]" />
      <div className="pointer-events-none absolute -bottom-28 -right-16 h-96 w-96 rounded-full bg-black/15" />
      <div className="relative mx-auto max-w-4xl px-5 py-20 text-center sm:px-8 lg:py-28">
        <FadeUp>
          <p className="label text-white/70">Step Into the Shattered Empire</p>
        </FadeUp>
        <FadeUp delay={0.08}>
          <h2 className="mt-6 font-display text-4xl font-light leading-[1.06] tracking-tight sm:text-5xl lg:text-6xl">
            The family you choose is
            <span className="italic"> waiting.</span>
          </h2>
        </FadeUp>
        <FadeUp delay={0.16}>
          <p className="mx-auto mt-6 max-w-xl font-serif text-[1.1rem] leading-relaxed text-white/80">
            Read Freeborn on Amazon, and join the reader list for poetry, short
            fiction, and updates from the wider universe.
          </p>
        </FadeUp>
        <FadeUp delay={0.24} className="mt-10 flex flex-wrap items-center justify-center gap-3.5">
          <a
            href={AMAZON_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="group relative overflow-hidden rounded-full bg-white px-8 py-4 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-crimson transition-transform duration-300 hover:-translate-y-0.5"
          >
            <span className="relative flex items-center gap-2.5">
              Buy on Amazon
              <ArrowUpRight className="h-3.5 w-3.5" />
            </span>
          </a>
          <button
            onClick={openSignup}
            className="inline-flex items-center gap-2.5 rounded-full border border-white/45 px-8 py-4 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-white transition-colors duration-300 hover:border-white hover:bg-white/10"
          >
            Join the reader list
          </button>
        </FadeUp>
      </div>
    </section>
  );
}

export default function Home() {
  return (
    <>
      <Hero />
      <WorldStrip />
      <Synopsis />
      <QuoteBand />
      <MapSection />
      <Reviews />
      <WatchSection />
      <AuthorBlock />
      <LatestPosts />
      <CtaBand />
    </>
  );
}
