import { ArrowUpRight } from "lucide-react";
import { RETAILERS, LIBRARY_LINKS, type Retailer } from "../data/site";
import { FadeUp, SectionLabel } from "./ui";

function Row({ r }: { r: Retailer }) {
  return (
    <a
      href={r.url}
      target="_blank"
      rel="noopener noreferrer"
      className="group flex items-center justify-between gap-4 border-b border-line py-4 transition-colors duration-300 hover:text-crimson"
    >
      <span>
        <span className="block font-display text-[1.15rem] font-semibold tracking-tight text-ink group-hover:text-crimson">
          {r.name}
        </span>
        <span className="block font-sans text-[11px] font-semibold uppercase tracking-[0.16em] text-muted">
          {r.format}
        </span>
      </span>
      <ArrowUpRight className="h-4 w-4 shrink-0 text-muted transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-crimson" />
    </a>
  );
}

export default function WhereToBuy() {
  return (
    <section className="border-y border-line bg-paper">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:py-24">
        <SectionLabel>Where to Buy</SectionLabel>
        <FadeUp delay={0.08}>
          <h2 className="mt-6 max-w-2xl font-display text-4xl font-light leading-[1.06] tracking-tight text-ink sm:text-5xl">
            Pick up <span className="italic text-crimson">Freeborn</span> anywhere you shop
          </h2>
          <p className="mt-5 max-w-2xl font-serif text-[1.05rem] leading-relaxed text-muted">
            Freeborn: Genesis is available in paperback and ebook. Prices and
            stock vary by store.
          </p>
        </FadeUp>
        <div className="mt-12 grid gap-10 md:grid-cols-3">
          {RETAILERS.map((g, i) => (
            <FadeUp key={g.group} delay={0.07 * i}>
              <h3 className="font-sans text-[11px] font-semibold uppercase tracking-[0.18em] text-crimson">
                {g.group}
              </h3>
              <div className="mt-3 border-t border-line">
                {g.items.map((r) => (
                  <Row key={r.url} r={r} />
                ))}
              </div>
            </FadeUp>
          ))}
        </div>
        <FadeUp delay={0.1}>
          <h3 className="mt-14 font-sans text-[11px] font-semibold uppercase tracking-[0.18em] text-crimson">
            Prefer the library?
          </h3>
          <div className="mt-3 grid gap-x-10 border-t border-line md:grid-cols-3">
            {LIBRARY_LINKS.map((r) => (
              <Row key={r.url} r={r} />
            ))}
          </div>
        </FadeUp>
      </div>
    </section>
  );
}
