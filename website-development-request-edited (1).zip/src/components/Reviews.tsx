import { Quote } from "lucide-react";
import { REVIEWS } from "../data/site";
import { FadeUp, SectionLabel } from "./ui";

export default function Reviews() {
  return (
    <section className="border-t border-line bg-surface">
      <div className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:py-24">
        <SectionLabel>What Readers Say</SectionLabel>
        <FadeUp delay={0.08}>
          <h2 className="mt-6 max-w-2xl font-display text-4xl font-light leading-[1.06] tracking-tight text-ink sm:text-5xl">
            Lost in the <span className="italic text-crimson">Shattered Empire</span>
          </h2>
        </FadeUp>
        <ul className="mt-12 grid gap-px overflow-hidden rounded-xl bg-line sm:grid-cols-2 lg:grid-cols-4">
          {REVIEWS.map((r, i) => (
            <FadeUp key={r.source} delay={0.07 * i} className="h-full">
              <li className="flex h-full flex-col bg-paper p-7">
                <Quote className="h-5 w-5 text-crimson" strokeWidth={1.6} />
                <p className="mt-5 flex-1 font-display text-[1.2rem] italic leading-snug text-ink">
                  {"\u201C"}{r.quote}{"\u201D"}
                </p>
                <p className="mt-6 font-sans text-[11px] font-semibold uppercase tracking-[0.16em] text-muted">
                  {r.source}
                </p>
              </li>
            </FadeUp>
          ))}
        </ul>
      </div>
    </section>
  );
}
