import { Play, ArrowUpRight } from "lucide-react";
import { YOUTUBE_URL } from "../data/site";
import { useSignup } from "./SignupProvider";
import { FadeUp, SectionLabel, SignupTrigger } from "./ui";

export default function WatchSection() {
  const { openSignup } = useSignup();
  return (
    <section className="border-t border-line bg-paper">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 py-20 sm:px-8 lg:grid-cols-12 lg:gap-16 lg:py-24">
        <div className="lg:col-span-6">
          <SectionLabel>Watch and Listen</SectionLabel>
          <FadeUp delay={0.08}>
            <h2 className="mt-6 font-display text-4xl font-light leading-[1.06] tracking-tight text-ink sm:text-5xl">
              Hear <span className="italic text-crimson">Freeborn</span>, chapter by chapter
            </h2>
            <p className="mt-5 max-w-xl font-serif text-[1.05rem] leading-relaxed text-muted">
              Follow the story on the Shattered Empire YouTube channel, one
              chapter at a time. A good way to meet Freeborn and Tishamon
              before you pick up the book.
            </p>
            <div className="mt-8">
              {YOUTUBE_URL ? (
                <a
                  href={YOUTUBE_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group inline-flex items-center justify-center gap-2.5 rounded-full bg-crimson px-7 py-3.5 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-white transition-shadow duration-300 hover:shadow-[0_14px_34px_-12px_rgba(184,31,43,0.65)]"
                >
                  Watch on YouTube
                  <ArrowUpRight className="h-3.5 w-3.5" />
                </a>
              ) : (
                <SignupTrigger
                  onClick={openSignup}
                  variant="solid"
                  label="Get the channel link"
                />
              )}
            </div>
          </FadeUp>
        </div>
        <div className="lg:col-span-6">
          <FadeUp delay={0.12}>
            <div className="relative flex aspect-video items-center justify-center overflow-hidden rounded-xl border border-line bg-surface-2">
              <div className="absolute inset-0 bg-gradient-to-br from-crimson/20 via-transparent to-transparent" />
              <span className="relative flex h-16 w-16 items-center justify-center rounded-full bg-crimson text-white">
                <Play className="ml-1 h-6 w-6" fill="currentColor" />
              </span>
            </div>
          </FadeUp>
        </div>
      </div>
    </section>
  );
}
