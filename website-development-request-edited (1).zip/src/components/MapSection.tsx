import { useEffect, useState } from "react";
import { Maximize2, X } from "lucide-react";
import { IMG } from "../data/site";
import { FadeUp, SectionLabel } from "./ui";
import RuneDivider from "./RuneDivider";

const PLACES = [
  { name: "Mist Forest and Aldorha", note: "A Mist Elf city that is not only in the forest, but of the forest." },
  { name: "The Fire Hills", note: "Where Tishamon settles after he is lamed, and where Freeborn is sent to the Fire Elf academy." },
  { name: "The Broken Lands", note: "Scarred by the Mage Wars. Freeborn crosses them alone." },
  { name: "Varstyva", note: "A dwarven city where Freeborn is honored and given gifts for the road." },
  { name: "Central Faire", note: "Home of the trade court, and the place a deadline points to." },
  { name: "Ports and cities of the road", note: "Alluch, Port Cleigh, Kingston, New Elastor, Tradeston and Stormhaven, all on Freeborn\u2019s long travels." },
];

function InkMap({ className = "" }: { className?: string }) {
  const mask = `url(${IMG.mapInk})`;
  return (
    <div
      role="img"
      aria-label="Hand-drawn map of the Shattered Empire showing the Mist Forest, Frost Peaks, Fire Hills, Broken Lands and coastal cities"
      className={`map-panel relative w-full overflow-hidden rounded-lg ${className}`}
      style={{ aspectRatio: "1656 / 2025" }}
    >
      <div
        className="map-ink absolute inset-[3%]"
        style={{ WebkitMaskImage: mask, maskImage: mask }}
      />
    </div>
  );
}

export default function MapSection() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <section className="relative overflow-hidden border-y border-line bg-surface">
      <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 py-20 sm:px-8 lg:grid-cols-12 lg:gap-16 lg:py-28">
        <div className="lg:col-span-6">
          <SectionLabel>The Map</SectionLabel>
          <FadeUp delay={0.08}>
            <h2 className="mt-6 font-display text-4xl font-light leading-[1.05] tracking-tight text-ink sm:text-5xl">
              Walk the <span className="italic text-crimson">Shattered Empire</span>
            </h2>
            <p className="mt-5 max-w-xl font-serif text-[1.05rem] leading-relaxed text-muted">
              Two thousand years after the Mage Wars, the continent is still
              broken. This is the hand-drawn map that opens the book, from the Sea of Ice in the north to the Dragon Isles in the south.
            </p>
            <RuneDivider className="mt-8 justify-start" />
            <ul className="mt-8 grid gap-x-8 gap-y-6 sm:grid-cols-2">
              {PLACES.map((p) => (
                <li key={p.name}>
                  <h3 className="font-rune text-[13px] font-semibold uppercase tracking-[0.18em] text-gold">
                    {p.name}
                  </h3>
                  <p className="mt-1.5 font-serif text-[0.98rem] leading-relaxed text-muted">
                    {p.note}
                  </p>
                </li>
              ))}
            </ul>
          </FadeUp>
        </div>

        <div className="lg:col-span-6">
          <FadeUp delay={0.12}>
            <button
              type="button"
              onClick={() => setOpen(true)}
              aria-label="Open the map of the Shattered Empire full size"
              className="group relative block w-full text-left"
            >
              <InkMap className="transition-transform duration-700 group-hover:scale-[1.015]" />
              <span className="absolute bottom-3 right-3 inline-flex items-center gap-2 rounded-full bg-paper/90 px-4 py-2 font-sans text-[10.5px] font-semibold uppercase tracking-[0.16em] text-ink ring-1 ring-line backdrop-blur">
                <Maximize2 className="h-3.5 w-3.5" /> View full size
              </span>
            </button>
          </FadeUp>
        </div>
      </div>

      {open && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Map of the Shattered Empire"
          className="fixed inset-0 z-[100] flex items-start justify-center overflow-auto bg-black/80 p-4 sm:p-8"
          onClick={() => setOpen(false)}
        >
          <button
            type="button"
            onClick={() => setOpen(false)}
            aria-label="Close map"
            className="fixed right-4 top-4 z-10 flex h-11 w-11 items-center justify-center rounded-full bg-paper text-ink ring-1 ring-line hover:text-crimson"
          >
            <X className="h-5 w-5" />
          </button>
          <div className="my-auto w-full max-w-4xl" onClick={(e) => e.stopPropagation()}>
            <InkMap />
          </div>
        </div>
      )}
    </section>
  );
}
