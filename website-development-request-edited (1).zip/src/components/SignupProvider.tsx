import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Check, BookOpen, Mail } from "lucide-react";

const EASE = [0.22, 1, 0.36, 1] as const;

type SignupCtx = { openSignup: () => void };
const Ctx = createContext<SignupCtx>({ openSignup: () => {} });

export const useSignup = () => useContext(Ctx);

const SEEN_KEY = "sc_freeborn_popup_seen";

export function SignupProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const autoFired = useRef(false);

  const openSignup = useCallback(() => setOpen(true), []);
  const value = useMemo(() => ({ openSignup }), [openSignup]);

  useEffect(() => {
    if (sessionStorage.getItem(SEEN_KEY)) return;

    const timer = window.setTimeout(() => {
      if (autoFired.current) return;
      autoFired.current = true;
      setOpen(true);
      sessionStorage.setItem(SEEN_KEY, "1");
    }, 14000);

    const onScroll = () => {
      if (autoFired.current) return;
      const depth =
        window.scrollY / (document.body.scrollHeight - window.innerHeight);
      if (depth > 0.55) {
        autoFired.current = true;
        clearTimeout(timer);
        setOpen(true);
        sessionStorage.setItem(SEEN_KEY, "1");
        window.removeEventListener("scroll", onScroll);
      }
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      clearTimeout(timer);
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <Ctx.Provider value={value}>
      {children}
      <AnimatePresence>
        {open && (
          <div className="fixed inset-0 z-[500] flex items-center justify-center px-4 py-8">
            {/* overlay */}
            <motion.button
              aria-label="Close sign up form"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={() => setOpen(false)}
              className="absolute inset-0 cursor-default bg-ink/70 backdrop-blur-[3px]"
            />

            {/* panel */}
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-labelledby="signup-title"
              initial={{ opacity: 0, y: 44, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 24, scale: 0.98 }}
              transition={{ duration: 0.5, ease: EASE }}
              className="relative z-10 grid w-full max-w-4xl overflow-hidden rounded-2xl bg-paper shadow-[0_50px_120px_-30px_rgba(23,20,15,0.6)] md:grid-cols-[0.85fr_1fr]"
            >
              {/* red panel */}
              <div className="relative hidden flex-col justify-between overflow-hidden bg-crimson p-9 text-white md:flex">
                <div className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-white/[0.07]" />
                <div className="pointer-events-none absolute -bottom-24 -left-12 h-64 w-64 rounded-full bg-black/15" />
                <div className="relative">
                  <BookOpen className="h-8 w-8" strokeWidth={1.4} />
                  <p className="mt-8 font-display text-4xl font-light leading-[1.1]">
                    Join the
                    <br />
                    <span className="italic">Shattered Empire.</span>
                  </p>
                  <p className="mt-5 max-w-[15rem] font-serif text-[0.95rem] leading-relaxed text-white/80">
                    Hear about Freeborn first, and get poetry, short fiction and
                    updates from the wider universe.
                  </p>
                </div>
                <div className="relative space-y-3">
                  {["News about Freeborn", "Poetry & short fiction", "Unsubscribe anytime"].map(
                    (t) => (
                      <div key={t} className="flex items-center gap-2.5">
                        <Check className="h-3.5 w-3.5 shrink-0" strokeWidth={3} />
                        <span className="font-sans text-[11.5px] font-medium uppercase tracking-[0.14em] text-white/90">
                          {t}
                        </span>
                      </div>
                    )
                  )}
                </div>
              </div>

              {/* form */}
              <div className="relative p-7 sm:p-10">
                <button
                  onClick={() => setOpen(false)}
                  aria-label="Close"
                  className="absolute right-5 top-5 flex h-9 w-9 items-center justify-center rounded-full border border-line text-muted transition-colors hover:border-crimson hover:text-crimson"
                >
                  <X className="h-4 w-4" />
                </button>

                <SignupForm onSuccess={() => {}} />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </Ctx.Provider>
  );
}

/** The form itself — reused in the popup and the footer band */
export function SignupForm({
  onSuccess,
  compact = false,
}: {
  onSuccess?: () => void;
  compact?: boolean;
}) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [consent, setConsent] = useState(true);
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return setError("Please enter your email address.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()))
      return setError("That email address doesn't look quite right.");
    if (!consent) return setError("Please tick the box so I'm allowed to write to you.");
    setError("");
    setDone(true);
    onSuccess?.();
  };

  if (done) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE }}
        className="flex h-full flex-col items-start justify-center py-6"
      >
        <span className="flex h-12 w-12 items-center justify-center rounded-full bg-crimson-soft text-crimson">
          <Check className="h-5 w-5" strokeWidth={2.5} />
        </span>
        <h3 className="mt-6 font-display text-3xl font-light tracking-tight text-ink">
          Welcome aboard.
        </h3>
        <p className="mt-3 max-w-sm font-serif text-[1.05rem] leading-relaxed text-muted">
          {name ? `${name}, ` : ""}you are on the list. Welcome to the Shattered Empire.
        </p>
      </motion.div>
    );
  }

  return (
    <form onSubmit={submit} className={compact ? "" : "pt-6 md:pt-0"}>
      <p className="label text-crimson">The Reader List</p>
      <h3
        id="signup-title"
        className="mt-4 font-display text-3xl font-light leading-[1.12] tracking-tight text-ink sm:text-4xl"
      >
        Updates from the <span className="italic text-crimson">Shattered Empire</span>
      </h3>
      <p className="mt-4 font-serif text-[1.05rem] leading-relaxed text-muted">
        News about Freeborn, plus poetry, short fiction, and updates on the
        wider universe.
      </p>

      <div className="mt-7 space-y-4">
        <div>
          <label htmlFor="su-name" className="label block text-muted">
            First name
          </label>
          <input
            id="su-name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Your first name"
            autoComplete="given-name"
            className="mt-2 w-full border-b border-line bg-transparent pb-2.5 font-serif text-[1.05rem] text-ink transition-colors placeholder:text-muted/50 focus:border-crimson"
          />
        </div>
        <div>
          <label htmlFor="su-email" className="label block text-muted">
            Email address <span className="text-crimson">*</span>
          </label>
          <input
            id="su-email"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            autoComplete="email"
            className="mt-2 w-full border-b border-line bg-transparent pb-2.5 font-serif text-[1.05rem] text-ink transition-colors placeholder:text-muted/50 focus:border-crimson"
          />
        </div>
      </div>

      <label className="mt-6 flex cursor-pointer items-start gap-3">
        <input
          type="checkbox"
          checked={consent}
          onChange={(e) => setConsent(e.target.checked)}
          className="mt-1 h-4 w-4 shrink-0 accent-[var(--crimson)]"
        />
        <span className="font-sans text-[12.5px] leading-relaxed text-muted">
          Yes, send me updates about Freeborn and the Shattered Empire. No
          spam, and you can unsubscribe at any time.
        </span>
      </label>

      {error && (
        <p className="mt-4 font-sans text-[12.5px] font-medium text-crimson">{error}</p>
      )}

      <button
        type="submit"
        className="group relative mt-7 flex w-full items-center justify-center gap-2.5 overflow-hidden rounded-full bg-crimson px-7 py-4 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-white transition-shadow duration-300 hover:shadow-[0_16px_36px_-14px_rgba(184,31,43,0.7)]"
      >
        <span className="absolute inset-0 -translate-x-full bg-crimson-dark transition-transform duration-400 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:translate-x-0" />
        <Mail className="relative h-3.5 w-3.5" />
        <span className="relative">Join the list</span>
      </button>

    </form>
  );
}
