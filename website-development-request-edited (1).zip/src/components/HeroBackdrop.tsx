import { useEffect, useRef } from "react";
import { IMG } from "../data/site";

/**
 * Animated hero scenery that adapts to the active theme:
 * parchment + brown ink in the white theme, night + gold ink in the dark theme.
 * Animations pause when the hero scrolls out of view.
 */
export default function HeroBackdrop() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver(([entry]) => {
      el.setAttribute("data-paused", String(!entry.isIntersecting));
    });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const mask = `url(${IMG.mapInk})`;
  return (
    <div
      ref={ref}
      aria-hidden="true"
      className="hero-scene pointer-events-none absolute inset-0 overflow-hidden"
    >
      <div className="hero-paper absolute inset-0" />
      <div
        className="map-ink hero-map-ink"
        style={{ WebkitMaskImage: mask, maskImage: mask }}
      />
      <div className="hero-veil absolute inset-0" />
      <div className="hero-fog fog-a" />
      <div className="hero-fog fog-b" />
    </div>
  );
}
