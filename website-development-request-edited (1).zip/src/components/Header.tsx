import { useEffect, useState } from "react";
import { NavLink, Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence, useScroll, useMotionValueEvent } from "framer-motion";
import { Menu, X, Sun, Moon, ArrowUpRight } from "lucide-react";
import { NAV } from "../data/site";
import { useSignup } from "./SignupProvider";
import Logo from "./Logo";

const EASE = [0.22, 1, 0.36, 1] as const;
const THEME_KEY = "sc_theme";

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [dark, setDark] = useState(true);
  const { openSignup } = useSignup();
  const { pathname } = useLocation();
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (v) => setScrolled(v > 30));

  /* theme: dark is the default, white is the alternative option */
  useEffect(() => {
    let saved: string | null = null;
    try {
      saved = localStorage.getItem(THEME_KEY);
    } catch {
      saved = null;
    }
    const isDark = saved !== "white";
    setDark(isDark);
    document.documentElement.classList.toggle("dark", isDark);
  }, []);

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    try {
      localStorage.setItem(THEME_KEY, next ? "dark" : "white");
    } catch {
      /* storage unavailable */
    }
    document.documentElement.classList.toggle("dark", next);
  };

  /* close mobile menu + lock scroll */
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  useEffect(() => setOpen(false), [pathname]);

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-[200] transition-all duration-500 ${
          scrolled
            ? "border-b border-line bg-paper/85 backdrop-blur-xl"
            : "border-b border-transparent bg-transparent"
        }`}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-6 px-5 py-4 sm:px-8 lg:py-5">
          {/* wordmark */}
          <Link to="/" aria-label="SESCRIBE home" className="group">
            <Logo />
          </Link>

          {/* desktop nav */}
          <nav className="hidden items-center gap-8 lg:flex">
            {NAV.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.to === "/"}
                className={({ isActive }) =>
                  `group relative font-sans text-[12px] font-semibold uppercase tracking-[0.15em] transition-colors duration-300 ${
                    isActive ? "text-crimson" : "text-ink/70 hover:text-crimson"
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    {l.label}
                    <span
                      className={`absolute -bottom-1.5 left-0 h-[2px] w-full origin-left bg-crimson transition-transform duration-400 ${
                        isActive ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100"
                      }`}
                    />
                  </>
                )}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2.5">
            {/* theme option */}
            <button
              onClick={toggleTheme}
              aria-label={dark ? "Switch to white theme" : "Switch to dark theme"}
              title={dark ? "White theme" : "Dark theme"}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-line text-ink/75 transition-all duration-300 hover:border-crimson hover:text-crimson"
            >
              {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>

            <button
              onClick={openSignup}
              className="group relative hidden overflow-hidden rounded-full bg-crimson px-5 py-2.5 font-sans text-[11.5px] font-semibold uppercase tracking-[0.15em] text-white transition-shadow duration-300 hover:shadow-[0_12px_28px_-12px_rgba(184,31,43,0.7)] sm:flex"
            >
              <span className="absolute inset-0 -translate-x-full bg-crimson-dark transition-transform duration-400 group-hover:translate-x-0" />
              <span className="relative flex items-center gap-1.5">
                Join the list
                <ArrowUpRight className="h-3.5 w-3.5" />
              </span>
            </button>

            <button
              onClick={() => setOpen(true)}
              aria-label="Open menu"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-line text-ink transition-colors hover:border-crimson hover:text-crimson lg:hidden"
            >
              <Menu className="h-[18px] w-[18px]" />
            </button>
          </div>
        </div>
      </header>

      {/* mobile drawer */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-[300] flex flex-col bg-paper lg:hidden"
          >
            <div className="flex items-center justify-between px-5 py-4 sm:px-8">
              <span className="font-display text-[15px] font-semibold tracking-tight text-ink">
                Steven Calkum
              </span>
              <button
                onClick={() => setOpen(false)}
                aria-label="Close menu"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-line text-ink transition-colors hover:border-crimson hover:text-crimson"
              >
                <X className="h-[18px] w-[18px]" />
              </button>
            </div>

            <nav className="flex flex-1 flex-col justify-center px-6 sm:px-8">
              {[...NAV].map((l, i) => (
                <motion.div
                  key={l.to}
                  initial={{ opacity: 0, y: 26 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.07 + i * 0.07, duration: 0.55, ease: EASE }}
                >
                  <NavLink
                    to={l.to}
                    end={l.to === "/"}
                    className={({ isActive }) =>
                      `flex items-baseline justify-between border-b border-line py-5 font-display text-[2rem] font-light tracking-tight transition-colors ${
                        isActive ? "text-crimson" : "text-ink"
                      }`
                    }
                  >
                    {l.label}
                    <span className="font-sans text-[11px] tracking-[0.2em] text-muted">
                      0{i + 1}
                    </span>
                  </NavLink>
                </motion.div>
              ))}
            </nav>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="space-y-4 px-6 pb-10 sm:px-8"
            >
              <button
                onClick={() => {
                  setOpen(false);
                  openSignup();
                }}
                className="w-full rounded-full bg-crimson py-4 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-white"
              >
                Join the reader list
              </button>
              <div className="flex items-center justify-between">
                <span className="font-sans text-[11px] uppercase tracking-[0.18em] text-muted">
                  Theme
                </span>
                <div className="flex overflow-hidden rounded-full border border-line">
                  <button
                    onClick={() => dark && toggleTheme()}
                    className={`px-4 py-2 font-sans text-[11px] font-semibold uppercase tracking-[0.14em] transition-colors ${
                      !dark ? "bg-crimson text-white" : "text-muted"
                    }`}
                  >
                    White
                  </button>
                  <button
                    onClick={() => !dark && toggleTheme()}
                    className={`px-4 py-2 font-sans text-[11px] font-semibold uppercase tracking-[0.14em] transition-colors ${
                      dark ? "bg-crimson text-white" : "text-muted"
                    }`}
                  >
                    Dark
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
