import { useState } from "react";
import { IMG } from "../data/site";

/**
 * Author photo. Loads /images/steven-calkum.jpg; if the file hasn't been
 * added yet it shows a clean monogram so the layout never breaks.
 */
export default function Portrait({
  className = "",
  imgClassName = "",
}: {
  className?: string;
  imgClassName?: string;
}) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div
        className={`flex items-center justify-center bg-gradient-to-br from-crimson to-crimson-dark ${className}`}
        role="img"
        aria-label="Steven Calkum"
      >
        <span className="font-display text-[3em] font-light italic text-white/90">SC</span>
      </div>
    );
  }

  return (
    <img
      src={IMG.author}
      alt="Portrait of author Steven Calkum"
      onError={() => setFailed(true)}
      className={`object-cover object-[50%_18%] ${className} ${imgClassName}`}
    />
  );
}
