/** Ornamental divider: gold lines with a small diamond sigil. */
export default function RuneDivider({ className = "" }: { className?: string }) {
  return (
    <div aria-hidden="true" className={`flex items-center justify-center gap-4 ${className}`}>
      <span className="h-px w-16 bg-gradient-to-r from-transparent to-gold/70 sm:w-28" />
      <svg width="26" height="26" viewBox="0 0 26 26" fill="none" className="text-gold">
        <path d="M13 2 L24 13 L13 24 L2 13 Z" stroke="currentColor" strokeWidth="1.2" />
        <path d="M13 7 L19 13 L13 19 L7 13 Z" fill="currentColor" opacity="0.85" />
      </svg>
      <span className="h-px w-16 bg-gradient-to-l from-transparent to-gold/70 sm:w-28" />
    </div>
  );
}
