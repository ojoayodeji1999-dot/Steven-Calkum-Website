/** SESCRIBE mark: an open book with a compass star rising from its spine. */
export function LogoMark({ size = 40 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      aria-hidden="true"
      className="shrink-0 text-gold"
    >
      <circle cx="24" cy="24" r="22.5" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="24" cy="24" r="19.5" stroke="currentColor" strokeWidth="0.5" opacity="0.5" />
      {/* compass star */}
      <path d="M24 5 L26 13 L24 15.5 L22 13 Z" fill="currentColor" />
      <path d="M17.5 12 L22.5 14 M30.5 12 L25.5 14" stroke="currentColor" strokeWidth="0.8" opacity="0.7" />
      {/* open book */}
      <path
        d="M24 19 C20 16.8 14.5 16.8 10 18.5 V33 C14.5 31.3 20 31.3 24 33.5 C28 31.3 33.5 31.3 38 33 V18.5 C33.5 16.8 28 16.8 24 19 Z"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinejoin="round"
        fill="currentColor"
        fillOpacity="0.12"
      />
      <path d="M24 19 V33.5" stroke="currentColor" strokeWidth="1.3" />
      <path d="M13 22 C16 21 19 21.2 21.5 22.4 M13 26 C16 25 19 25.2 21.5 26.4 M26.5 22.4 C29 21.2 32 21 35 22 M26.5 26.4 C29 25.2 32 25 35 26" stroke="currentColor" strokeWidth="0.8" opacity="0.7" strokeLinecap="round" />
      {/* base flourish */}
      <path d="M17 38 H31" stroke="currentColor" strokeWidth="1" opacity="0.7" />
    </svg>
  );
}

export default function Logo({ showTag = true }: { showTag?: boolean }) {
  return (
    <span className="flex items-center gap-3">
      <LogoMark />
      <span className="leading-none">
        <span className="block font-rune text-[19px] font-semibold tracking-[0.3em] text-ink">
          SESCRIBE
        </span>
        {showTag && (
          <span className="mt-1.5 block font-sans text-[8.5px] font-semibold uppercase tracking-[0.26em] text-gold">
            Shattered Empire Scribe
          </span>
        )}
      </span>
    </span>
  );
}
