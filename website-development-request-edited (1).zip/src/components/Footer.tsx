import Logo from "./Logo";
import { Link } from "react-router-dom";
import { ArrowUp, ArrowUpRight, MapPin, PenLine } from "lucide-react";
import { NAV, AMAZON_URL, PEN_NAME } from "../data/site";
import { useSignup } from "./SignupProvider";
import { POSTS } from "../data/posts";

export default function Footer() {
  const { openSignup } = useSignup();
  const year = new Date().getFullYear();

  return (
    <footer className="relative border-t border-line bg-surface">
      {/* newsletter band */}
      <div className="border-b border-line">
        <div className="mx-auto grid max-w-7xl items-center gap-8 px-5 py-14 sm:px-8 lg:grid-cols-[1.2fr_1fr] lg:py-16">
          <div>
            <p className="label text-crimson">The Reader List</p>
            <h2 className="mt-4 font-display text-3xl font-light leading-[1.12] tracking-tight text-ink sm:text-4xl">
              Poetry, short fiction, and news from the{" "}
              <span className="italic text-crimson">Shattered Empire.</span>
            </h2>
          </div>
          <div className="flex flex-col items-start gap-4 lg:items-end">
            <p className="max-w-sm font-serif text-[1.02rem] leading-relaxed text-muted lg:text-right">
              Be first to hear about Freeborn and the wider universe it belongs to.
            </p>
            <button
              onClick={openSignup}
              className="group relative overflow-hidden rounded-full bg-crimson px-7 py-3.5 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-white transition-shadow duration-300 hover:shadow-[0_14px_32px_-12px_rgba(184,31,43,0.65)]"
            >
              <span className="absolute inset-0 -translate-x-full bg-crimson-dark transition-transform duration-400 group-hover:translate-x-0" />
              <span className="relative flex items-center gap-2">
                Sign up
                <ArrowUpRight className="h-3.5 w-3.5" />
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* columns */}
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 sm:grid-cols-2 sm:px-8 lg:grid-cols-4">
        <div>
          <Logo />
          <p className="mt-5 max-w-xs font-serif text-[0.98rem] leading-relaxed text-muted">
            Fantasy author and former Bureau of Land Management range manager.
            Author of <em className="text-ink">Freeborn</em>, an adult coming-of-age fantasy.
          </p>
          <a
            href={AMAZON_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-5 inline-flex items-center gap-1.5 font-sans text-[11.5px] font-semibold uppercase tracking-[0.15em] text-crimson hover:underline"
          >
            Find it on Amazon
            <ArrowUpRight className="h-3 w-3" />
          </a>
        </div>

        <div>
          <p className="label text-ink">Pages</p>
          <ul className="mt-5 space-y-3">
            {NAV.map((l) => (
              <li key={l.to}>
                <Link
                  to={l.to}
                  className="font-sans text-[13.5px] text-muted transition-colors hover:text-crimson"
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="label text-ink">Latest Posts</p>
          <ul className="mt-5 space-y-3">
            {POSTS.slice(0, 3).map((p) => (
              <li key={p.slug}>
                <Link
                  to={`/blog/${p.slug}`}
                  className="font-sans text-[13.5px] leading-snug text-muted transition-colors hover:text-crimson"
                >
                  {p.title}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="label text-ink">Contact</p>
          <ul className="mt-5 space-y-3.5">
            <li className="flex items-start gap-2.5">
              <PenLine className="mt-0.5 h-3.5 w-3.5 shrink-0 text-crimson" />
              <span className="font-sans text-[13.5px] text-muted">
                Online as {PEN_NAME}
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-crimson" />
              <span className="font-sans text-[13.5px] text-muted">Wyoming, USA</span>
            </li>
            <li>
              <Link
                to="/contact"
                className="font-sans text-[13.5px] text-crimson hover:underline"
              >
                Send a message
              </Link>
            </li>
          </ul>
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            aria-label="Back to top"
            className="mt-7 flex h-10 w-10 items-center justify-center rounded-full border border-line text-muted transition-all duration-300 hover:border-crimson hover:bg-crimson hover:text-white"
          >
            <ArrowUp className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="border-t border-line">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-5 py-7 font-sans text-[11px] uppercase tracking-[0.16em] text-muted sm:flex-row sm:px-8">
          <span>© {year} Steven Calkum. All rights reserved.</span>
          <span className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-crimson" />
            Freeborn — on Amazon
          </span>
        </div>
      </div>
    </footer>
  );
}
