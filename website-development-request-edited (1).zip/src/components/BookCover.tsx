import { useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { IMG } from "../data/site";

/**
 * The Freeborn cover. Loads /images/freeborn-cover.jpg; until that file is
 * added, a typographic stand-in is shown so the layout never breaks.
 */
export default function BookCover({
  className = "",
  float = false,
}: {
  className?: string;
  float?: boolean;
}) {
  const reduce = useReducedMotion();
  const [failed, setFailed] = useState(false);

  return (
    <div className={`relative ${className}`}>
      <motion.div
        animate={float && !reduce ? { y: [0, -14, 0] } : undefined}
        transition={{ duration: 6.5, repeat: Infinity, ease: "easeInOut" }}
        className="relative"
      >
        {/* stacked pages behind */}
        <div className="absolute inset-y-[1.5%] left-[3px] w-[10px] rounded-l-sm bg-surface-2" />
        <div className="absolute inset-y-[3%] left-[6px] w-[10px] rounded-l-sm bg-surface" />

        <div
          style={{ containerType: "inline-size" }}
          className="relative aspect-[2/3] w-full overflow-hidden rounded-[3px] bg-[#07110c] shadow-[0_38px_70px_-28px_rgba(23,20,15,0.55),0_0_0_1px_rgba(23,20,15,0.08)]"
        >
          {!failed ? (
            <img
              src={IMG.cover}
              alt="Freeborn by Steven Calkum — book cover"
              onError={() => setFailed(true)}
              className="absolute inset-0 h-full w-full object-cover"
            />
          ) : (
            <div className="absolute inset-0 bg-gradient-to-b from-[#0a1d12] via-[#07110c] to-black">
              <div className="flex h-full flex-col items-center justify-between p-[8cqw] text-center">
                <div>
                  <h3 className="font-display text-[15cqw] font-normal uppercase leading-none tracking-[0.04em] text-[#3f9a62]">
                    Freeborn
                  </h3>
                  <p className="mt-[5cqw] font-sans text-[3.6cqw] font-medium uppercase tracking-[0.22em] text-white/85">
                    Steven Calkum
                  </p>
                </div>
                <p className="font-sans text-[3cqw] uppercase tracking-[0.3em] text-white/40">
                  Cover image
                </p>
              </div>
            </div>
          )}

          {/* spine shading + sheen */}
          <div className="pointer-events-none absolute inset-y-0 left-0 w-[6%] bg-gradient-to-r from-black/35 to-transparent" />
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent opacity-30" />
        </div>
      </motion.div>
    </div>
  );
}
