/** Slow rising embers for atmosphere. Decorative only; paused for reduced motion. */
const EMBERS = Array.from({ length: 26 }, (_, i) => ({
  left: `${(i * 37 + 11) % 100}%`,
  s: `${3 + ((i * 5) % 6)}px`,
  d: `${11 + ((i * 3) % 9)}s`,
  delay: `${-((i * 7) % 16)}s`,
  dx: `${((i % 2 ? 1 : -1) * (20 + ((i * 11) % 60)))}px`,
  rest: `${8 + ((i * 13) % 70)}%`,
}));

export default function Embers({ className = "" }: { className?: string }) {
  return (
    <div
      aria-hidden="true"
      className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`}
    >
      {EMBERS.map((e, i) => (
        <span
          key={i}
          className="ember"
          style={
            {
              left: e.left,
              "--s": e.s,
              "--d": e.d,
              "--delay": e.delay,
              "--dx": e.dx,
              "--rest": e.rest,
            } as React.CSSProperties
          }
        />
      ))}
    </div>
  );
}
