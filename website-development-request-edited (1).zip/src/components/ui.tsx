import { motion, useReducedMotion } from "framer-motion";
import type { ReactNode } from "react";
import { ArrowUpRight, ExternalLink } from "lucide-react";
import { AMAZON_URL } from "../data/site";

const EASE = [0.22, 1, 0.36, 1] as const;

export function FadeUp({
  children,
  delay = 0,
  className,
  y = 40,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  y?: number;
}) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: reduce ? 0 : y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-70px" }}
      transition={{ duration: 0.85, delay, ease: EASE }}
    >
      {children}
    </motion.div>
  );
}

export function WordReveal({
  text,
  className,
  delay = 0,
}: {
  text: string;
  className?: string;
  delay?: number;
}) {
  const reduce = useReducedMotion();
  const words = text.split(" ");
  return (
    <span className={className}>
      {words.map((w, i) => (
        <span key={i} className="inline-block overflow-hidden pb-[0.1em] -mb-[0.1em] align-bottom">
          <motion.span
            className="inline-block"
            initial={{ y: reduce ? 0 : "108%" }}
            whileInView={{ y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.8, delay: delay + i * 0.03, ease: EASE }}
          >
            {w}
            {i < words.length - 1 ? "\u00A0" : ""}
          </motion.span>
        </span>
      ))}
    </span>
  );
}

export function SectionLabel({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <FadeUp className={className}>
      <div className="flex items-center gap-3">
        <span className="h-px w-8 bg-crimson" />
        <span className="label text-crimson">{children}</span>
      </div>
    </FadeUp>
  );
}

/** Primary red call-to-action — links to the book on Amazon */
export function AmazonButton({
  label = "Buy on Amazon",
  variant = "solid",
  className = "",
}: {
  label?: string;
  variant?: "solid" | "outline";
  className?: string;
}) {
  if (variant === "outline") {
    return (
      <a
        href={AMAZON_URL}
        target="_blank"
        rel="noopener noreferrer"
        className={`group inline-flex items-center justify-center gap-2.5 rounded-full border border-ink/25 px-7 py-3.5 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-ink transition-all duration-300 hover:border-crimson hover:text-crimson ${className}`}
      >
        {label}
        <ExternalLink className="h-3.5 w-3.5" />
      </a>
    );
  }
  return (
    <a
      href={AMAZON_URL}
      target="_blank"
      rel="noopener noreferrer"
      className="group relative inline-flex items-center justify-center gap-2.5 overflow-hidden rounded-full bg-crimson px-7 py-3.5 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-white transition-all duration-300 hover:shadow-[0_14px_34px_-12px_rgba(184,31,43,0.65)]"
    >
      <span className="absolute inset-0 -translate-x-full bg-crimson-dark transition-transform duration-400 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:translate-x-0" />
      <span className="relative">{label}</span>
      <ArrowUpRight className="relative h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
    </a>
  );
}

/** Red "join the reader list" trigger used across the site */
export function SignupTrigger({
  onClick,
  label = "Join the reader list",
  variant = "outline",
  className = "",
}: {
  onClick: () => void;
  label?: string;
  variant?: "solid" | "outline";
  className?: string;
}) {
  const base =
    "group relative inline-flex items-center justify-center gap-2.5 overflow-hidden rounded-full px-7 py-3.5 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] transition-all duration-300";
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        variant === "solid"
          ? `${base} ${className} bg-crimson text-white hover:shadow-[0_14px_34px_-12px_rgba(184,31,43,0.65)]`
          : `${base} ${className} border border-crimson text-crimson hover:text-white`
      }
    >
      {variant === "outline" && (
        <span className="absolute inset-0 -translate-y-full bg-crimson transition-transform duration-400 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:translate-y-0" />
      )}
      <span className="relative">{label}</span>
      <ArrowUpRight className="relative h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
    </button>
  );
}

export function Divider({ className = "" }: { className?: string }) {
  return (
    <motion.div
      className={`h-px origin-left bg-line ${className}`}
      initial={{ scaleX: 0 }}
      whileInView={{ scaleX: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 1.2, ease: EASE }}
    />
  );
}
