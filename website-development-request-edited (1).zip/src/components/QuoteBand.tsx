import Embers from "./Embers";
import RuneDivider from "./RuneDivider";
import { FadeUp } from "./ui";

/** Word-art quote band. Parchment in the white theme, night in the dark theme. */
export default function QuoteBand() {
  return (
    <section className="atmos-quote relative overflow-hidden border-y border-line">
      <Embers className="hidden dark:block" />
      <span
        aria-hidden="true"
        className="pointer-events-none absolute left-4 top-0 select-none font-display text-[16rem] leading-none text-gold/20 sm:left-16 sm:text-[22rem]"
      >
        {"\u201C"}
      </span>
      <div className="relative mx-auto max-w-4xl px-6 py-24 text-center sm:py-32">
        <FadeUp>
          <p className="font-rune text-[11px] font-semibold uppercase tracking-[0.4em] text-gold">
            From the prologue
          </p>
          <blockquote className="mt-8 font-display text-3xl font-light italic leading-[1.25] text-ink sm:text-5xl">
            Raise him to value life, freedom and justice. Raise him to stand against
            evil in all of its forms.
          </blockquote>
          <RuneDivider className="mt-12" />
          <p className="mt-6 font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-muted">
            A dying mother{"\u2019"}s last request
          </p>
        </FadeUp>
      </div>
    </section>
  );
}
