import { useEffect } from "react";
import { HashRouter, Routes, Route, useLocation, Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import Header from "./components/Header";
import Footer from "./components/Footer";
import { SignupProvider } from "./components/SignupProvider";
import Home from "./pages/Home";
import Book from "./pages/Book";
import Blog from "./pages/Blog";
import BlogPost from "./pages/BlogPost";
import Contact from "./pages/Contact";

const EASE = [0.22, 1, 0.36, 1] as const;

/** Reset scroll + focus on every route change */
function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
  }, [pathname]);
  return null;
}

function NotFound() {
  return (
    <section className="mx-auto flex min-h-[70vh] max-w-3xl flex-col items-center justify-center px-5 pt-28 text-center sm:px-8">
      <p className="label text-crimson">Page not found</p>
      <h1 className="mt-6 font-display text-6xl font-light tracking-tight text-ink sm:text-8xl">
        Four <span className="italic text-crimson">oh four</span>
      </h1>
      <p className="mt-6 max-w-md font-serif text-[1.1rem] leading-relaxed text-muted">
        This page has wandered off the trail. The rest of the Shattered Empire
        is right where you left it.
      </p>
      <Link
        to="/"
        className="mt-10 rounded-full bg-crimson px-8 py-4 font-sans text-[12px] font-semibold uppercase tracking-[0.18em] text-white transition-shadow duration-300 hover:shadow-[0_16px_36px_-14px_rgba(184,31,43,0.7)]"
      >
        Back to the home page
      </Link>
    </section>
  );
}

function AnimatedRoutes() {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <motion.main
        key={location.pathname}
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -8 }}
        transition={{ duration: 0.45, ease: EASE }}
      >
        <Routes location={location}>
          <Route path="/" element={<Home />} />
          <Route path="/book" element={<Book />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<BlogPost />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </motion.main>
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <HashRouter>
      <SignupProvider>
        <div className="grain-light relative min-h-screen bg-paper">
          <ScrollToTop />
          <Header />
          <AnimatedRoutes />
          <Footer />
        </div>
      </SignupProvider>
    </HashRouter>
  );
}
