export type Post = {
  slug: string;
  title: string;
  excerpt: string;
  readTime: string;
  category: string;
  image: string | null;
  featured?: boolean;
  blocks: Block[];
};

export type Block =
  | { type: "p"; text: string }
  | { type: "h"; text: string }
  | { type: "quote"; text: string }
  | { type: "pull"; text: string }
  | { type: "list"; items: string[] };

export const POSTS: Post[] = [
  {
    slug: "eight-years-by-hand",
    title: "Eight Years, Written by Hand",
    excerpt:
      "From 1998 to 2006 I drafted, edited and transcribed Freeborn by hand and on office computers, in the gaps of a working life.",
    readTime: "5 min read",
    category: "The Long Draft",
    image: "/images/blog-1.jpg",
    featured: true,
    blocks: [
      {
        type: "p",
        text: "Freeborn did not arrive in a flash, and it did not arrive quickly. Between 1998 and 2006 I spent eight years drafting, editing and transcribing it, by hand and on office computers. Most of it was written in the downtime of a working life.",
      },
      { type: "h", text: "A book written in the cracks" },
      {
        type: "p",
        text: "I worked for the Bureau of Land Management, and the job came with its own rhythm. There were long days out on public grazing lands, and then long stretches at a desk writing technical reports and environmental assessments. The downtime was where Freeborn lived. I had those quiet hours, and a stubborn refusal to let the story go.",
      },
      {
        type: "quote",
        text: "I kept rewriting until I wanted to read it myself. That was the only standard I trusted.",
      },
      { type: "h", text: "Why so many drafts" },
      {
        type: "p",
        text: "I have always been a voracious reader, and I learned how to write by reading. When I started, I knew what I loved on the page, and I could see exactly how far my own sentences fell short of it. So I rewrote. Then I rewrote the rewrite. I did not stop until I reached a draft that I would happily pick up and read for pleasure, as a reader and not as the author.",
      },
      {
        type: "pull",
        text: "Patience is not glamorous, but it is most of the job.",
      },
      {
        type: "p",
        text: "In 2014 I retired early to give my full attention to creative fiction. I am glad every day that I did not hurry this book.",
      },
    ],
  },
  {
    slug: "reading-the-land",
    title: "What a Range Manager Knows About Building a World",
    excerpt:
      "Years of reading real landscapes for a living shaped the lava fields, mountain trails and forests of the Shattered Empire.",
    readTime: "5 min read",
    category: "The World",
    image: "/images/blog-2.jpg",
    featured: true,
    blocks: [
      {
        type: "p",
        text: "I grew up on a small ranch in East Central Colorado, and I studied Range Management and Agriculture at Colorado State University. Then I spent my career as a range manager, monitoring public grazing lands, carrying out environmental assessments, and working with local ranchers. All of it was about one skill: learning to read land.",
      },
      { type: "h", text: "Land tells you things" },
      {
        type: "p",
        text: "A good range manager looks at a hillside and sees its history. Where the water goes, what has been grazed, what is recovering, and what is in trouble. Land is never just scenery. It is evidence, and it rewards close attention.",
      },
      {
        type: "p",
        text: "That habit followed me onto the page. In Freeborn, the characters read the land the way I was trained to. Tishamon the Long Walker does not just walk across the Shattered Empire. He notices what the ground is telling him, and he teaches his apprentice to notice it too. Tracking, after all, is just land-reading with higher stakes.",
      },
      {
        type: "quote",
        text: "If a landscape in a book could not exist, a reader who has worked outdoors will feel it straight away.",
      },
      { type: "h", text: "From reports to fantasy" },
      {
        type: "p",
        text: "Years of writing technical reports and environmental impact statements gave me something I did not expect: a foundation in precise, structured writing. You learn to say exactly what you mean, to put things in the right order, and to cut what does not earn its place. It is not the usual training for a fantasy author, but it shows on every page of Freeborn.",
      },
      {
        type: "list",
        items: [
          "Volcanic lava fields, which I have tried to write as places with real ground and real hazards",
          "Mountain trails with weather, altitude and distance that matter",
          "Living tree cities, where the architecture grows rather than is built",
          "Dwarven mines, which are as much about air and darkness as stone",
        ],
      },
      {
        type: "pull",
        text: "A made-up world still has to obey the land.",
      },
    ],
  },
  {
    slug: "tishamon-the-long-walker",
    title: "Meet Tishamon the Long Walker",
    excerpt:
      "A five-hundred-year-old elf woodsman, and the heart of the story: why Freeborn is, at its core, about a mentor and an apprentice.",
    readTime: "4 min read",
    category: "The Characters",
    image: null,
    blocks: [
      {
        type: "p",
        text: "Freeborn was born in a blizzard to an escaped slave who died giving him freedom. That is how the book begins. The boy grows up in a smugglers' village that never wanted him, and what he gets instead of a family is Tishamon.",
      },
      { type: "h", text: "The Long Walker" },
      {
        type: "p",
        text: "Tishamon is a five-hundred-year-old Copper Elf woodsman, known across the Shattered Empire as the Long Walker. He swore to a dying stranger that he would raise her son, and he keeps that promise by teaching Freeborn to track, to fight, to speak the languages of many peoples, and to think his way out of trouble, first on camping trips from the village and then on the road. It is a very old kind of story: the apprentice and the master. I wanted to tell it with care.",
      },
      {
        type: "quote",
        text: "Knowledge is not meant to take pain away, but to give the learner enough perspective that the pain is more bearable. (Tishamon, Chapter 1)",
      },
      { type: "h", text: "Why the mentor matters" },
      {
        type: "p",
        text: "A half-elf with no people belongs nowhere, and that is the wound at the centre of the book. Tishamon is the one person who accepts Freeborn as he is. Much of what follows, the choices Freeborn makes and the enemies he faces, comes from what he was taught on the fringe.",
      },
      {
        type: "pull",
        text: "Family is not only who you are born to. It is who stays.",
      },
      {
        type: "p",
        text: "That idea, the family you choose, runs through the whole novel. It is why Freeborn is a coming-of-age story first and a fantasy adventure second.",
      },
    ],
  },
  {
    slug: "who-freeborn-is-for",
    title: "A Note on Content: Who Freeborn Is For",
    excerpt:
      "Freeborn is an adult fantasy. An honest, plain note on what it contains, so readers can choose with their eyes open.",
    readTime: "3 min read",
    category: "Readers",
    image: null,
    blocks: [
      {
        type: "p",
        text: "I would rather tell you plainly what is in this book than have it surprise you. Freeborn is an adult fantasy, written for adult readers.",
      },
      { type: "h", text: "What it deals with" },
      {
        type: "list",
        items: [
          "Slavery",
          "Sexual violence",
          "Captivity",
          "Graphic battle violence",
        ],
      },
      {
        type: "p",
        text: "These are not there for effect. The story is about a boy born to an escaped slave, and about the real consequences of fighting back against prejudice. I have tried to write hard subjects honestly and with care, but they are hard, and they will not suit every reader.",
      },
      {
        type: "quote",
        text: "If a book is going to show you something difficult, it owes you a warning first.",
      },
      { type: "h", text: "And what else you will find" },
      {
        type: "p",
        text: "It is also a story about identity, honor, and the family you choose. It has a mentor and apprentice at its heart, friendships across elf, dwarf and halfling lines, and a world I have tried to build with love: tree cities, mines, mountains and lava fields. There is swordplay, archery and hand-to-hand combat written with care.",
      },
      {
        type: "pull",
        text: "Read it if it sounds like your kind of book. Skip it if it does not. Either choice is a good one.",
      },
    ],
  },
  {
    slug: "shattered-empire-scribe",
    title: "Writing as Shattered Empire Scribe",
    excerpt:
      "Poetry, short fiction and updates from the wider universe of the Shattered Empire, and where to find them.",
    readTime: "3 min read",
    category: "Behind the Pen",
    image: null,
    blocks: [
      {
        type: "p",
        text: "Online, I write as Shattered Empire Scribe. It is where I share poetry, short fiction, and updates on the wider universe that Freeborn belongs to.",
      },
      { type: "h", text: "Why a second name" },
      {
        type: "p",
        text: "Freeborn is one story in a much larger world. The Shattered Empire has more history, more places, and more people than one novel can hold. Writing as Shattered Empire Scribe lets me explore those corners in smaller pieces, such as a poem, a scene, or a short tale, without waiting for a whole book.",
      },
      {
        type: "quote",
        text: "Not everything in a world belongs in the novel. Some of it just wants to be written down.",
      },
      { type: "h", text: "Stay in touch" },
      {
        type: "p",
        text: "If you have read Freeborn and want more of the world, the reader list is the best place to start. Join it and I will let you know when there is something new to read.",
      },
    ],
  },
];

export const getPost = (slug: string) => POSTS.find((p) => p.slug === slug);

export const CATEGORIES = Array.from(new Set(POSTS.map((p) => p.category)));
