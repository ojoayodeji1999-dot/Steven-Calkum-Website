/**
 * IMAGES — drop these two files into /public/images/ and they appear everywhere:
 *   steven-calkum.jpg   (author portrait)
 *   freeborn-cover.jpg  (book cover)
 */
export const IMG = {
  author: "/images/steven-calkum.jpg",
  cover: "/images/freeborn-cover.jpg",
  map: "/images/shattered-empire-map.jpg",
  mapInk: "/images/shattered-empire-map-ink.png",
};

/** Direct link to the current Amazon US paperback edition. */
export const AMAZON_URL =
  "https://www.amazon.com/Freeborn-Genesis-Saga-Book/dp/1684869544";

export type Retailer = { name: string; format: string; url: string };

/**
 * Every retail link verified for the book's current editions
 * (Freeborn: Genesis, Freeborn Saga Book 1, 2024). Library lending is separate.
 */
export const RETAILERS: { group: string; items: Retailer[] }[] = [
  {
    group: "United States",
    items: [
      { name: "Amazon", format: "Paperback", url: "https://www.amazon.com/Freeborn-Genesis-Saga-Book/dp/1684869544" },
      { name: "Amazon", format: "Kindle ebook", url: "https://www.amazon.com/dp/B0C5H9254Z" },
      { name: "Barnes & Noble", format: "Paperback", url: "https://www.barnesandnoble.com/w/freeborn-steven-calkum/1147000994" },
      { name: "Walmart", format: "Paperback", url: "https://www.walmart.com/ip/Freeborn-Book-1-Genesis-Paperback-9781684869541/13519568258" },
    ],
  },
  {
    group: "Canada and United Kingdom",
    items: [
      { name: "Amazon Canada", format: "Kindle ebook", url: "https://www.amazon.ca/Freeborn-Book-Genesis-Steven-Calkum-ebook/dp/B0DLJC654R" },
      { name: "Amazon UK", format: "Kindle ebook", url: "https://www.amazon.co.uk/Freeborn-Book-Genesis-Steven-Calkum-ebook/dp/B0DLJC654R" },
    ],
  },
  {
    group: "Europe and Australia",
    items: [
      { name: "Amazon Germany", format: "Paperback", url: "https://www.amazon.de/Freeborn-Steven-Calkum/dp/1949473317" },
      { name: "Adlibris (Sweden)", format: "Paperback", url: "https://www.adlibris.com/se/bok/freeborn-9781684869541" },
      { name: "Akademibokhandeln (Sweden)", format: "Paperback", url: "https://akademibokhandeln.se/bok/freeborn/9781684869541" },
      { name: "Amazon Australia", format: "Paperback", url: "https://www.amazon.com.au/Freeborn-Steven-Calkum/dp/1640454896" },
    ],
  },
];

export const LIBRARY_LINKS: Retailer[] = [
  { name: "Hoopla", format: "Borrow the ebook", url: "https://www.hoopladigital.com/ebook/Freeborn-Steven-Calkum/17460300" },
  { name: "OverDrive", format: "Borrow the ebook", url: "https://www.overdrive.com/media/11313708/freeborn" },
];

/**
 * Paste the channel link here when you have it. Until then the Watch section
 * shows a "get the link" signup button instead of a dead link.
 */
export const YOUTUBE_URL = "";

export const REVIEWS: { quote: string; source: string }[] = [
  { quote: "This book takes the reader into a wonderful fantasy world.", source: "Lucille A. Eagleboy, reader review" },
  { quote: "Overall, Freeborn is a thrilling fantasy adventure.", source: "SA Examiner book review" },
  { quote: "The author\u2019s imagination is extensive, as evidenced in the detailed world building.", source: "Amazon UK reader review" },
  { quote: "Excellent fantasy novel.", source: "Verified Amazon reader, 2023" },
];

export const PEN_NAME = "Shattered Empire Scribe";

export const BOOK = {
  title: "Freeborn",
  author: "Steven Calkum",
  genre: "Adult Fantasy",
  subgenre: "Coming-of-age fantasy",
  tagline: "A half-elf with no people belongs nowhere.",
  logline:
    "Freeborn was born in a blizzard to an escaped slave who died giving him freedom. Raised on the fringe by Tishamon the Long Walker, a five-hundred-year-old elf woodsman, he learns to track, fight, and think his way across the Shattered Empire.",
  conflict:
    "But a half-elf with no people belongs nowhere. When a powerful Fire Elf family decides he must pay for fighting back, Freeborn faces a deadline, a debt, and enemies on every road.",
  about:
    "This is a coming-of-age fantasy about identity, honor, and the family you choose.",
  loveIt: [
    {
      title: "Mentor & apprentice",
      body: "At its core, the story of a boy and the five-hundred-year-old elf who teaches him to survive.",
    },
    {
      title: "A richly built world",
      body: "Living tree cities, dwarven mines, mountain trails and volcanic lava fields.",
    },
    {
      title: "Real consequences",
      body: "Fighting back against prejudice costs something, and the book never pretends otherwise.",
    },
    {
      title: "Combat written with care",
      body: "Swordplay, archery and hand-to-hand fighting that respects how it actually works.",
    },
    {
      title: "Friendship across borders",
      body: "Bonds that cross elf, dwarf and halfling lines.",
    },
  ],
  contentNote:
    "Freeborn is an adult fantasy. It deals with slavery, sexual violence, captivity, and graphic battle violence. Reader discretion is advised.",
  worldFeatures: [
    "Living tree cities",
    "Dwarven mines",
    "Volcanic lava fields",
    "Mountain trails",
    "Swordplay & archery",
    "Elf, dwarf & halfling friendships",
    "The Shattered Empire",
    "The family you choose",
  ],
};

export const AUTHOR = {
  name: "Steven Calkum",
  born: 1967,
  location: "Wyoming",
  tagline: "Fantasy author, former range manager, lifelong reader of the land.",
  short:
    "Steven Calkum is an American fantasy author, agricultural professional, and former natural resource manager. Raised on a small ranch in East Central Colorado, he now lives in Wyoming.",
  timeline: [
    {
      year: "1967",
      title: "Born & raised on a ranch",
      body: "A small ranch in East Central Colorado gave him an early, lasting connection to rural landscapes and the outdoors.",
    },
    {
      year: "College",
      title: "Colorado State University",
      body: "A Bachelor of Science in Range Management, then a Master's degree in Agriculture.",
    },
    {
      year: "Career",
      title: "Bureau of Land Management",
      body: "As a range manager he monitored public grazing lands, conducted environmental assessments, and worked alongside local ranchers.",
    },
    {
      year: "1998–2006",
      title: "The long draft",
      body: "Eight years drafting, editing and transcribing his debut novel by hand and on office computers during professional downtime.",
    },
    {
      year: "2014",
      title: "Early retirement",
      body: "He retired early to give his full attention to creative fiction, and now lives in Wyoming building his career as a writer and storyteller.",
    },
  ],
};

export const NAV = [
  { label: "Home", to: "/" },
  { label: "About the Book", to: "/book" },
  { label: "Blog", to: "/blog" },
  { label: "Contact", to: "/contact" },
];

/** Contact form "reason" options — rendered as a select */
export const CONTACT_REASONS = [
  "General message",
  "A question about Freeborn",
  "Reader feedback",
  "Press & media",
  "Collaboration",
];
